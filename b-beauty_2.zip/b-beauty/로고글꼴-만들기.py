#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
로고 글꼴(src/fonts/*.woff2) 을 다시 만드는 스크립트.

언제 쓰나:
  1) 로고 글꼴을 다른 것으로 바꿀 때
  2) 로고 문구를 'B-Beauty' 가 아닌 다른 글자로 바꿀 때
     → 아래 TEXT 에 새 글자를 넣어야 합니다. 넣지 않으면 그 글자만 다른 글꼴로 나옵니다.

쓰는 법:
  python3 로고글꼴-만들기.py 원본글꼴.otf
  python3 로고글꼴-만들기.py 원본글꼴.otf --name quentin
  python3 로고글꼴-만들기.py 원본글꼴.otf --text "B-Beauty 부산"

만든 뒤에는 build.py 의 _font 파일명을 새 이름으로 맞추고 python3 build.py 를 돌립니다.

필요한 것: pip install fonttools brotli
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(HERE, 'src', 'fonts')

# 로고와 큰 제목에 실제로 쓰는 글자. 용량을 줄이려고 이 글자만 남깁니다.
#   홈 화면 로고            : B-Beauty
#   사업소개 히어로 3줄      : B-Wave / Here Begins the Next / Beauty Standard
TEXT = 'B-Beauty B-Wave Here Begins the Next Beauty Standard'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('source', help='원본 글꼴 파일 (.otf 또는 .ttf)')
    ap.add_argument('--name', help='만들 파일 이름 (기본: 원본 이름을 소문자로)')
    ap.add_argument('--text', default=TEXT, help='남길 글자 (기본: %s)' % TEXT)
    a = ap.parse_args()

    try:
        from fontTools import subset
    except ImportError:
        sys.exit('fonttools 가 필요합니다:  pip install fonttools brotli')

    if not os.path.exists(a.source):
        sys.exit('원본 글꼴을 찾을 수 없습니다: %s' % a.source)

    name = a.name or os.path.splitext(os.path.basename(a.source))[0].lower().replace(' ', '')
    out = os.path.join(FONT_DIR, name + '.woff2')
    os.makedirs(FONT_DIR, exist_ok=True)

    opt = subset.Options()
    opt.notdef_outline = True
    opt.layout_features = ['*']
    font = subset.load_font(a.source, opt)
    s = subset.Subsetter(options=opt)
    s.populate(text=a.text)
    s.subset(font)
    font.flavor = 'woff2'
    subset.save_font(font, out, opt)

    print('만들었습니다: %s (%.1f KB)' % (out, os.path.getsize(out) / 1024))
    print('남긴 글자: %s' % a.text)
    print()
    print('다음 순서:')
    print("  1. build.py 의 _font 줄을 '%s.woff2' 로 맞춥니다" % name)
    print('  2. style.css 의 @font-face 위 주석에 저작권·라이선스를 적습니다')
    print('  3. python3 build.py')


if __name__ == '__main__':
    main()
