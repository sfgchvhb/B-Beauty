/* =========================================================
   B-BEAUTY — 부산 코스메틱 연합 플랫폼
   원본 Vite/React 프로젝트(App, Navbar, Hero, BrandShowcase,
   ProductExplorer, CompassQuiz, Community, CartDrawer, SearchBar)를
   의존성 없는 단일 HTML로 1:1 이식
   ========================================================= */
(function () {
  'use strict';

  /* =========================================================
     STATE
     ========================================================= */
  var S = {
    view: 'home', lang: 'KR', scrolled: false, mobileMenu: false,

    brandId: 'amaranth', dossier: false,

    brandFilter: 'All', category: 'All', concern: 'All', sort: 'featured', query: '',
    activeProduct: null,

    evTab: 'events', evPage: 1, evDetail: null, coupon: false,
    noticeCat: 'All', noticeQ: '', noticeOpen: null,
    quiz: { active: false, step: 'welcome', idx: 0, answers: [] },

    comm: {
      state: 'list', cat: 'all', brandTab: 'all', q: '', post: null,
      form: { cat: 'review', brand: 'amaranth', product: '', rating: 5, writer: '', title: '', content: '' }
    },
    posts: [],

    vidPage: 0, video: null,
    evAll: false,

    toast: null, toastTimer: null
  };

  var VIEWS = [
    { id: 'home', key: 'nav.home' },
    { id: 'intro', key: 'nav.intro' },
    { id: 'brands', key: 'nav.brands', drop: 'brands' },
    { id: 'products', key: 'nav.products', drop: 'products' },
    { id: 'quiz', key: 'nav.quiz' },
    { id: 'community', key: 'nav.community' }
  ];

  /* 원본 ProductExplorer: categories / skinConcerns
     (Haircare 는 원본 탭 목록에 누락되어 있어 제품 2종이 '전체'에서만 보였으므로 추가) */
  var CATEGORIES = ['All', 'Skincare', 'Bodycare', 'Cleansing', 'Haircare', 'Makeup'];
  var CONCERNS = ['All', 'Hydration', 'Soothing', 'Anti-aging', 'Brightening', 'Pore care'];

  var CAT_L = {
    All: ['전체 품목', 'All Products', '全部产品'],
    Skincare: ['스킨케어', 'Skincare', '护肤'],
    Bodycare: ['바디케어', 'Bodycare', '身体护理'],
    Cleansing: ['클렌징', 'Cleansing', '洁面卸妆'],
    Haircare: ['헤어케어', 'Haircare', '洗护发'],
    Makeup: ['메이크업', 'Makeup', '彩妆']
  };
  var CON_L = {
    All: ['모든 피부고민', 'All Concerns', '所有肌肤问题'],
    Hydration: ['수분 보습', 'Hydration', '补水保湿'],
    Soothing: ['진정 카밍', 'Soothing', '舒缓修护'],
    'Anti-aging': ['탄력 노화', 'Anti-Aging', '紧致抗衰'],
    Brightening: ['미백 윤기', 'Brightening', '美白祛斑'],
    'Pore care': ['모공 각질', 'Pore Care', '收缩毛孔']
  };
  var SORT_L = {
    featured: ['추천 순', 'Featured', '热销推荐'],
    'price-asc': ['낮은 가격 순', 'Price: Low to High', '价格: 从低到高'],
    'price-desc': ['높은 가격 순', 'Price: High to Low', '价格: 从高到低'],
    rating: ['평점 높은 순', 'Highest Rating', '按评分排序']
  };
  /* 원본 announcementCategories → 코드 매핑 */
  var NOTICE_CATS = [
    { code: 'All', kr: '전체', l: ['전체', 'All', '全部'] },
    { code: 'Notice', kr: '공지', l: ['공지', 'Notice', '公告'] },
    { code: 'Guide', kr: '안내', l: ['안내', 'Guide', '指南'] },
    { code: 'Event', kr: '이벤트', l: ['이벤트', 'Event', '活动'] },
    { code: 'Delivery', kr: '배송', l: ['배송', 'Delivery', '物流'] },
    { code: 'System', kr: '시스템', l: ['시스템', 'System', '系统'] }
  ];
  var NOTICE_CLS = { '공지': 'c-notice', '이벤트': 'c-event', '안내': 'c-guide', '배송': 'c-delivery', '시스템': 'c-system' };

  /* 원본 renderOptionIcon 의 lucide 아이콘 → 문자 대체 */
  var QICON = {
    Droplet: '💧', Sparkles: '✦', ShieldAlert: '🛡', Leaf: '🌿', Dna: '🧬', Heart: '♥',
    Trash2: '♻', Crown: '♛', Compass: '◎', Flower: '❀', Wind: '≋', Smile: '☺'
  };

  /* =========================================================
     HELPERS
     ========================================================= */
  function L(a) { return S.lang === 'KR' ? a[0] : S.lang === 'CN' ? a[2] : a[1]; }
  function pick(kr, en, cn) { return S.lang === 'KR' ? kr : S.lang === 'CN' ? cn : en; }
  function T(k) { var e = window.UI[k]; return e ? (e[S.lang] || e.KR) : k; }
  function TC() { return window.TC[S.lang] || window.TC.KR; }
  function D() { return window.DATASET[S.lang] || window.DATASET.KR; }
  function brands() { return D().brands; }

  /* 영문명이 따로 없는 브랜드(숲의 사랑)는 보조 라벨을 비운다 */
  function subEn(b) {
    if (!b.englishName || b.englishName === b.name) return '';
    /* 중국어 '艾达拉 (L'DARA)' 처럼 이름 안에 영문명이 이미 들어 있으면 또 붙이지 않는다 */
    if (b.name && b.name.indexOf(b.englishName) > -1) return '';
    return b.englishName;
  }
  /* '브랜드명 (영문명)' — 영문명이 없으면 브랜드명만 */
  function nameFull(b) { return subEn(b) ? (b.name + ' (' + b.englishName + ')') : b.name; }

  function products() { return D().products; }
  function brandIdx(id) { var r = 0; brands().forEach(function (b, i) { if (b.id === id) r = i; }); return r; }
  function brandById(id) { return brands().filter(function (b) { return b.id === id; })[0] || brands()[0]; }
  function productById(id) { return products().filter(function (p) { return p.id === id; })[0] || null; }
  function img(p) { return !p ? '' : (window.IMG[p] || p); }
  function won(n) { return '₩' + Number(n).toLocaleString('ko-KR'); }
  /* 공식몰 제품은 '가격 문의'(B2B 비공개)일 수 있다 */
  function priceText(p) {
    if (p && p.priceOnRequest) {
      return p.priceLabel || pick('가격 문의', 'Price on request', '价格咨询');
    }
    return won(p ? p.price : 0);
  }
  /* 이미지가 깨지면 브랜드 대표 이미지로 자동 대체 */
  /* ---------- 이미지 로딩 (3단 폴백) ----------
     1) 원본 주소 — 동기화 후에는 내려받은 로컬 파일(images/…)이라 항상 뜬다
     2) 공식몰 원격 이미지가 도용방지(Referer 차단)로 막히면 이미지 프록시로 재시도
     3) 그래도 안 되면 브랜드 대표 이미지
     제품마다 다른 이미지가 나오도록, 2단계까지는 반드시 원래 상품 사진을 시도한다. */
  var IMG_PROXY = 'https://images.weserv.nl/?url=';
  var IMG_PROXY2 = 'https://wsrv.nl/?url=';

  /* 최후 폴백 — 제품마다 다른 안내 그림을 만든다.
     (같은 대체 이미지를 쓰면 모든 제품이 똑같아 보이므로 제품명을 넣어 구분한다) */
  function placeholder(name, brandName) {
    /* 제품명을 한 줄에 밀어넣지 않고 여러 줄로 나눠 잘리지 않게 한다 */
    var words = String(name || '').split(/\s+/).filter(Boolean);
    var lines = [], cur = '';
    var LIMIT = 17;                                   // 한 줄 최대 글자 수(한글 기준)
    words.forEach(function (w) {
      while (w.length > LIMIT) {                      // 아주 긴 단어는 강제로 끊는다
        if (cur) { lines.push(cur); cur = ''; }
        lines.push(w.slice(0, LIMIT));
        w = w.slice(LIMIT);
      }
      if (!cur) { cur = w; }
      else if ((cur + ' ' + w).length <= LIMIT) { cur += ' ' + w; }
      else { lines.push(cur); cur = w; }
    });
    if (cur) lines.push(cur);
    lines = lines.slice(0, 4);

    var top = 372;
    var body = lines.map(function (ln, i) {
      return '<text x="300" y="' + (top + i * 27) + '" text-anchor="middle" ' +
        'font-family="A2z, sans-serif" font-size="17" font-weight="500" fill="#005a73">' + esc(ln) + '</text>';
    }).join('');

    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" ' +
      'viewBox="0 0 600 600">' +
      '<rect width="600" height="600" fill="#f7fdfe"/>' +
      '<circle cx="300" cy="232" r="58" fill="none" stroke="#bdeffd" stroke-width="3"/>' +
      '<path d="M272 246l20 20 32-38 28 38" fill="none" stroke="#a3ebfc" stroke-width="3" ' +
      'stroke-linecap="round" stroke-linejoin="round"/>' +
      '<circle cx="282" cy="212" r="8" fill="#bdeffd"/>' +
      '<text x="300" y="336" text-anchor="middle" font-family="A2z, sans-serif" font-size="15" ' +
      'font-weight="700" letter-spacing="2" fill="#004b5c">' + esc(brandName || '') + '</text>' +
      body +
      '<text x="300" y="' + (top + lines.length * 27 + 22) + '" text-anchor="middle" ' +
      'font-family="A2z, sans-serif" font-size="12" letter-spacing="1" ' +
      'fill="#8fc9d8">IMAGE UNAVAILABLE</text></svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  window.bbImgFail = function (node) {
    var step = parseInt(node.getAttribute('data-step') || '0', 10);
    var orig = node.getAttribute('data-orig') || '';
    var bid = node.getAttribute('data-brand') || '';
    var nm = node.getAttribute('alt') || '';
    if (step === 0 && /^https?:\/\//.test(orig)) {
      node.setAttribute('data-step', '1');
      node.src = IMG_PROXY + encodeURIComponent(orig.replace(/^https?:\/\//, '')) + '&w=640&output=jpg';
      return;
    }
    if (step <= 1 && /^https?:\/\//.test(orig)) {
      node.setAttribute('data-step', '2');
      node.src = IMG_PROXY2 + encodeURIComponent(orig);
      return;
    }
    node.onerror = null;
    node.setAttribute('data-step', '3');
    var bn = '';
    try { bn = brandById(bid).name; } catch (e) { }
    node.src = placeholder(nm, bn);
  };

  function imgTag(src, alt, brandId, extra) {
    var url = img(src);
    return '<img src="' + esc(url) + '" alt="' + esc(alt || '') + '"' +
      (extra || '') +
      ' referrerpolicy="no-referrer" data-orig="' + esc(url) + '"' +
      ' data-brand="' + esc(brandId || '') + '" data-step="0"' +
      ' onerror="bbImgFail(this)">';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function el(id) { return document.getElementById(id); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function starRow(n, cls) {
    var out = '';
    for (var i = 1; i <= 5; i++) out += '<span' + (i <= n ? '' : ' class="off"') + '>★</span>';
    return '<span class="stars' + (cls ? ' ' + cls : '') + '">' + out + '</span>';
  }
  function catLabel(c) { return L(CAT_L[c] || [c, c, c]); }
  function conLabel(c) { return L(CON_L[c] || [c, c, c]); }

  /* 브랜드 링크 — 공식몰(officialUrl)과 스마트스토어(storeUrl).
     숲의 사랑처럼 공식몰이 없는 브랜드는 스마트스토어만 나온다. */
  function mallLinks(b, cls, withName) {
    if (!b) return '';
    var out = '';
    var a = function (url, label) {
      return '<a class="' + cls + '" href="' + esc(url) + '" target="_blank" rel="noopener">' +
        esc(label) + (withName ? ' (' + esc(b.name) + ')' : '') + ' ↗</a>';
    };
    if (b.officialUrl) out += a(b.officialUrl, pick('공식몰 바로가기', 'Visit Official Store', '前往官方商城'));
    if (b.storeUrl) out += a(b.storeUrl, pick('스마트스토어 바로가기', 'Naver Smart Store', '前往 Naver 商城'));
    return out;
  }

  /* 가격 안내문 — 표시 가격은 공식몰 기준 */
  function priceNote(brandId) {
    var b = null;
    if (brandId) {
      b = brands().filter(function (x) { return x.id === brandId; })[0] || null;
    }
    /* 공식몰이 없는 브랜드(숲의 사랑)는 스마트스토어로 연결한다 */
    var site = b ? (b.officialUrl || b.storeUrl || '') : '';
    return '<p class="syncnote">' + esc(pick(
      '표시 가격은 각 브랜드 공식몰 기준이며 실제 판매가와 다를 수 있습니다. 최종 가격은 공식몰에서 확인해 주세요.',
      'Prices shown are based on each brand\'s official store and may differ from the current price. Please confirm on the official store.',
      '所示价格以各品牌官方商城为准，可能与实时价格存在差异。最终价格请以官方商城为准。')) +
      (site ? ' <a href="' + esc(site) + '" target="_blank" rel="noopener">' +
        esc(pick('공식몰 바로가기', 'Official store', '前往官方商城')) + ' ↗</a>' : '') + '</p>';
  }


  /* 알림 토스트 (담기 기능은 제거, 쿠폰·글쓰기 안내용으로만 사용) */
  function showToast(m) {
    S.toast = m;
    if (S.toastTimer) clearTimeout(S.toastTimer);
    S.toastTimer = setTimeout(function () { S.toast = null; render(); }, 3500);
  }

  /* 제품 카드용 — 공식몰과 스마트스토어 버튼을 함께.
     새 탭이 막힌 환경(미리보기 iframe 등)에서도 이동하도록 클릭을 직접 처리한다. */
  function storeLinks(p, cls) {
    var b = brandById(p.brandId);
    if (!b) return '';
    /* 공식몰이 없는 브랜드는 스토어 하나만 — 같은 주소가 두 번 나오지 않게 한다 */
    var off = b.officialUrl || '';
    var st = b.storeUrl || '';
    if (!off && !st) off = p.officialUrl || '';
    if (off && st && off === st) st = '';
    var a = function (url, label) {
      return '<a class="' + cls + '" href="' + esc(url) + '" target="_blank" rel="noopener"' +
        ' data-ext="' + esc(url) + '">' + esc(label) + '</a>';
    };
    return (off ? a(off, pick('공식몰', 'Store', '商城')) : '') +
      (st ? a(st, pick('스토어', 'N Store', 'N商城')) : '');
  }

  /* 담기 버튼을 대신하는 공식몰 링크 */
  function storeLink(p, cls, label) {
    var b = brandById(p.brandId);
    var url = p.officialUrl || (b && (b.officialUrl || b.storeUrl)) || '';
    if (!url) return '';
    return '<a class="' + (cls || 'btn btn-sm btn-sq btn-solid') + '" href="' + esc(url) +
      '" target="_blank" rel="noopener">' +
      esc(label || pick('공식몰에서 보기', 'View on store', '前往商城查看')) + ' ↗</a>';
  }

  function go(view, opt) {
    opt = opt || {};
    S.view = view; S.mobileMenu = false;
    try { if (location.hash.slice(1) !== view) history.replaceState(null, '', '#' + view); } catch (e) { }
    if (opt.brandId) S.brandId = opt.brandId;
    if (opt.brandFilter) { S.brandFilter = opt.brandFilter; S.category = 'All'; S.concern = 'All'; }
    window.scrollTo({ top: 0, behavior: 'smooth' });
    render();
  }

  /* =========================================================
     NAVBAR (Navbar.tsx)
     ========================================================= */
  function navbar() {
    var langs = ['KR', 'EN', 'CN'].map(function (l, i) {
      return (i ? '<span class="sep">|</span>' : '') +
        '<button data-lang="' + l + '" class="' + (S.lang === l ? 'on' : '') + '">' + l + '</button>';
    }).join('') + '<span style="opacity:.6">🌐</span>';

    var menu = VIEWS.map(function (v) {
      var drop = '';
      if (v.drop) {
        drop = '<div class="dropdown">' + brands().map(function (b) {
          return '<button data-' + (v.drop === 'brands' ? 'navbrand' : 'navshop') + '="' + b.id + '">' +
            '<span class="dn">' + esc(b.name) + '</span>' +
            '<span class="de">' + esc(subEn(b)) + '</span></button>';
        }).join('') + '</div>';
      }
      return '<div class="navitem' + (S.view === v.id ? ' on' : '') + '">' +
        '<button data-go="' + v.id + '">' + esc(T(v.key)) +
        (v.drop ? '<span class="caret">▼</span>' : '') + '</button>' + drop + '</div>';
    }).join('');

    var mobile = S.mobileMenu ? '<div class="mobilemenu">' +
      '<div class="msearch">' + searchBox('mob', 'full') + '</div>' +
      VIEWS.map(function (v) {
        var out = '<button class="mm' + (S.view === v.id ? ' on' : '') + '" data-go="' + v.id + '">' +
          esc(T(v.key)) + '</button>';
        if (v.drop) {
          out += '<div class="msub">' + brands().map(function (b) {
            return '<button data-' + (v.drop === 'brands' ? 'navbrand' : 'navshop') + '="' + b.id + '">' +
              '<span>' + esc(b.name) + '</span><span>' + esc(subEn(b)) + '</span></button>';
          }).join('') + '</div>';
        }
        return out;
      }).join('') +
      '<div class="mlang">' + ['KR', 'EN', 'CN'].map(function (l) {
        return '<button data-lang="' + l + '" class="' + (S.lang === l ? 'on' : '') + '">' + l + '</button>';
      }).join('<span>/</span>') + '</div></div>' : '';

    return '<nav class="nav' + (S.scrolled ? ' scrolled' : '') + '" id="main-nav"><div class="nav-in">' +
      '<div class="langs">' + langs + '</div>' +
      '<button class="logo" data-go="home">' +
      '<span class="l1">B<em>-</em>BEAUTY</span><span class="l2">Busan wave alliance</span></button>' +
      '<div class="navright"><div class="navmenu">' + menu + searchBox('nav', 'bar') + '</div>' +
      '<button class="burger" id="mobile-menu-toggle" aria-label="menu">' + (S.mobileMenu ? '✕' : '☰') + '</button>' +
      '</div>' + mobile + '</div></nav>';
  }

  /* =========================================================
     SEARCHBAR (SearchBar.tsx) — 페이지 + 브랜드 + 제품 2섹션
     ========================================================= */
  function searchPages() {
    var nav = pick('홈페이지 탐색', 'Navigation', '页面导航');
    var list = [
      { id: 'page-home', title: pick('홈 (메인 화면)', 'Home', '首页'), cat: nav, view: 'home', ic: '◎' },
      { id: 'page-intro', title: pick('사업소개 (B-BEAUTY 연합)', 'Brand Intro', '品牌介绍'), cat: nav, view: 'intro', ic: '✦' },
      { id: 'page-brands', title: pick('참여 브랜드 쇼케이스', 'Participating Brands', '参展品牌展厅'), cat: nav, view: 'brands', ic: '🏢' },
      {
        id: 'page-products', title: pick('전체 제품 라인업 (스킨케어/바디)', 'All Products', '全部产品线'),
        cat: pick('제품 탐색', 'Products', '产品导航'), view: 'products', brand: 'All', ic: '▤'
      },
      {
        id: 'page-quiz', title: pick('이벤트 & 공지사항 / 스킨케어 진단', 'Event, Notice & Skincare Quiz', '活动与公告 / 肤质诊断'),
        cat: nav, view: 'quiz', ic: '◈'
      },
      { id: 'page-community', title: pick('B-BEAUTY 커뮤니티 게시판', 'Community Forum', '联盟社区论坛'), cat: nav, view: 'community', ic: '💬' }
    ];
    brands().forEach(function (b) {
      list.push({
        id: 'brand-nav-' + b.id,
        title: nameFull(b) + ' - ' +
          pick('브랜드 및 제품 보기', 'View Brand & Products', '查看品牌与产品'),
        cat: pick('브랜드 탐색', 'Brands', '品牌导航'), view: 'products', brand: b.id, ic: '❖'
      });
    });
    return list;
  }

  function searchBox(pfx, variant) {
    var ph = variant === 'bar' ? pick('제품 검색', 'Search', '搜索产品') : T('products.search_placeholder');
    return '<div class="sbox ' + variant + '">' +
      '<span class="mag">⌕</span>' +
      '<input type="text" id="si-' + pfx + '" placeholder="' + esc(ph) + '" autocomplete="off">' +
      '<button class="clr hidden" id="sc-' + pfx + '" aria-label="clear">✕</button>' +
      '<div class="sdrop hidden" id="sd-' + pfx + '"></div></div>';
  }

  function wireSearch(pfx) {
    var input = el('si-' + pfx), drop = el('sd-' + pfx), clr = el('sc-' + pfx);
    if (!input) return;

    function paint() {
      var raw = input.value.trim(), q = raw.toLowerCase();
      clr.classList.toggle('hidden', !raw);

      var pages = searchPages(), prods = products(), mp, mr;
      if (!q) { mp = pages.slice(0, 4); mr = prods.slice(0, 4); }
      else {
        mp = pages.filter(function (p) { return (p.title + ' ' + p.cat).toLowerCase().indexOf(q) > -1; });
        mr = prods.filter(function (p) {
          return (p.name + ' ' + p.englishName + ' ' + p.brandName + ' ' + p.category).toLowerCase().indexOf(q) > -1 ||
            (p.skinConcerns || []).some(function (c) { return c.toLowerCase().indexOf(q) > -1; }) ||
            (p.ingredients || []).some(function (i) { return i.toLowerCase().indexOf(q) > -1; });
        });
      }
      var total = mp.length + mr.length;

      var html = '<div class="sdrop-head"><span>✦ ' +
        (raw ? esc(pick("'" + raw + "' 검색 결과", "Results for '" + raw + "'", "'" + raw + "' 搜索结果"))
          : esc(pick('추천 제품 및 빠른 이동', 'Quick Navigation & Suggestions', '推荐产品与快速导航'))) +
        '</span><span class="cnt">' + total + esc(pick('개 항목', ' items', '个项目')) + '</span></div>';

      if (mp.length) {
        html += '<div class="sgroup"><div class="gt">' +
          esc(pick('홈페이지 탐색 및 메뉴', 'Pages & Navigation', '页面与菜单导航')) + '</div>' +
          mp.map(function (p) {
            return '<button class="srow" data-spage="' + p.id + '">' +
              '<span class="ic">' + p.ic + '</span>' +
              '<span class="tx"><span class="t1">' + esc(p.title) + '</span>' +
              '<span class="t2">' + esc(p.cat) + '</span></span><span class="arw">›</span></button>';
          }).join('') + '</div>';
      }
      if (mr.length) {
        html += '<div class="sgroup"><div class="gt">' +
          esc(pick('제품 탐색', 'Products', '产品搜索')) + '</div>' +
          mr.map(function (p) {
            return '<button class="srow" data-sprod="' + p.id + '">' +
              imgTag(p.image, '', p.brandId) +
              '<span class="tx"><span class="t2"><span class="bp">' + esc(p.brandName) + '</span>' +
              esc(catLabel(p.category)) + '</span>' +
              '<span class="t1">' + esc(p.name) + '</span></span>' +
              '<span class="pr">' + won(p.price) + '</span></button>';
          }).join('') + '</div>';
      }
      if (!total) {
        html += '<div class="snone">' + esc(pick("'" + raw + "' 에 대한 검색 결과가 없습니다.",
          "No results found for '" + raw + "'.", "未找到 '" + raw + "' 的相关结果")) + '</div>';
      }

      drop.innerHTML = html;
      drop.classList.remove('hidden');

      Array.prototype.forEach.call(drop.querySelectorAll('[data-spage]'), function (b) {
        b.addEventListener('mousedown', function (e) {
          e.preventDefault();
          var p = searchPages().filter(function (x) { return x.id === b.getAttribute('data-spage'); })[0];
          if (p) go(p.view, p.brand ? { brandFilter: p.brand } : {});
        });
      });
      Array.prototype.forEach.call(drop.querySelectorAll('[data-sprod]'), function (b) {
        b.addEventListener('mousedown', function (e) {
          e.preventDefault();
          var id = b.getAttribute('data-sprod'), p = productById(id);
          if (!p) return;
          go('products', { brandFilter: p.brandId });
          setTimeout(function () {
            var t = el('product-card-' + id) || el('product-explorer-section');
            if (t) t.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }, 140);
        });
      });
    }

    input.addEventListener('focus', paint);
    input.addEventListener('input', paint);
    input.addEventListener('blur', function () { setTimeout(function () { drop.classList.add('hidden'); }, 170); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') drop.classList.add('hidden');
      if (e.key === 'Enter') {
        S.query = input.value.trim(); S.brandFilter = 'All'; S.category = 'All'; S.concern = 'All';
        go('products');
      }
    });
    clr.addEventListener('mousedown', function (e) { e.preventDefault(); input.value = ''; input.focus(); paint(); });
  }

  /* =========================================================
     HOME (App.tsx home view)
     ========================================================= */
  function viewHome() {
    return '<section class="cine view">' +
      '<div class="cine-bg"><img src="' + img(window.HERO_IMAGE) + '" alt="B-Beauty Cinematic Hero">' +
      '<div class="g1"></div><div class="g2"></div><div class="glow"></div></div>' +
      '<div class="home-in"><h1 data-go="intro">B-Beauty</h1>' +
      '<div class="sw">' + searchBox('home', 'hero') + '</div></div></section>';
  }

  /* =========================================================
     HERO (Hero.tsx)
     ========================================================= */
  function heroSection() {
    return '<section class="cine">' +
      '<div class="cine-bg"><img src="' + img(window.HERO_IMAGE) + '" alt="B-Beauty Hero">' +
      '<div class="g1"></div><div class="g2"></div><div class="glow"></div></div>' +
      '<div class="hero-in">' +
      '<div class="hero-badge"><i></i><span>' + 'Busan Cosmetic Platform Alliance' + '</span><i></i></div>' +
      '<h1><span class="l1">B-Wave</span><span class="l2">Here Begins the Next</span>' +
      '<span class="l3">Beauty Standard</span></h1>' +
      '<p class="lead">' + esc(T('hero.description')) + '</p>' +
      '<div class="hero-acts">' +
      '<button class="btn-ghost" data-hero-explore="1"><span>' + esc(T('hero.cta')) + '</span><span>→</span></button>' +
      '<button class="scroller" data-hero-explore="1"><span>Scroll Down</span><i>▾</i></button></div></div>' +
      '<div class="hero-foot">' + 'Busan Metropolitan City Cooperative' + '</div></section>';
  }

  function viewIntro() {
    return '<div class="view">' + heroSection() +
      '<div id="main-content-anchor"></div>' + brandShowcase() + '</div>';
  }

  /* =========================================================
     BRAND SHOWCASE (BrandShowcase.tsx)
     ========================================================= */
  function brandShowcase() {
    var b = brandById(S.brandId);
    var bp = products().filter(function (p) { return p.brandId === b.id; });

    /* 상단 디렉토리 바 */
    var dirbar = '<div class="dirbar"><div class="dl">' + esc(T('showcase.directory')) + '</div><div class="dp">' +
      brands().map(function (x) {
        return '<button class="dirpill' + (x.id === b.id ? ' on' : '') + '" data-brand="' + x.id + '">' +
          '<span>' + esc(x.name) + '</span><span class="en">' + esc(subEn(x)) + '</span></button>';
      }).join('') + '</div></div>';

    /* 시그니처 제품 — 큰 사진 + 옆에 제품 설명 */
    var sig = bp.slice(0, 1).map(function (p) {
      var tags = (p.ingredients || []).slice(0, 4);
      return '<div class="sig">' +
        '<div class="th">' + imgTag(p.image, p.name, p.brandId) +
        (p.badge ? '<span class="sig-badge">' + esc(p.badge) + '</span>' : '') + '</div>' +
        '<div class="bd">' +
        '<span class="cat">' + esc(catLabel(p.category)) +
        (p.capacity && p.capacity !== '-' ? ' · ' + esc(p.capacity) : '') + '</span>' +
        '<h5>' + esc(p.name) + '</h5>' +
        '<p class="ds">' + esc(p.description) + '</p>' +
        (function () {
          /* 상세 설명은 '요약 + 안내문' 구조라, 요약과 겹치지 않는 뒷부분만 보여준다 */
          var parts = String(p.detailedDescription || '').split(/\n\s*\n/);
          var extra = parts.length > 1 ? parts[parts.length - 1].trim() : '';
          return (extra && extra !== p.description)
            ? '<p class="ds long">' + esc(extra) + '</p>' : '';
        })() +
        (tags.length ? '<div class="sig-tags">' + tags.map(function (t) {
          return '<span>' + esc(t) + '</span>';
        }).join('') + '</div>' : '') +
        '<div class="r2"><div class="prices">' +
        (p.originalPrice && !p.priceOnRequest && p.originalPrice > p.price ?
          '<span class="was">' + won(p.originalPrice) + '</span>' : '') +
        '<span class="now' + (p.priceOnRequest ? ' ask' : '') + '">' + esc(priceText(p)) + '</span>' +
        (p.originalPrice && p.originalPrice > p.price ?
          '<span class="sig-off">' + esc(pick('공식 할인가', 'Official Price', '官方折扣价')) + '</span>' : '') +
        '</div>' +
        storeLink(p, 'btn btn-sm btn-sq sig-cta',
          p.priceOnRequest ? pick('공식몰에서 가격 문의', 'Ask on store', '前往商城咨询')
                           : pick('공식몰에서 구매하기', 'Buy on official store', '前往官方商城购买')) +
        '</div></div></div>';
    }).join('');

    /* BEST 상품 4종 — 리뷰 수 · 평점 순으로 뽑는다 */
    var bestList = bp.slice().sort(function (a, b2) {
      if ((b2.reviewsCount || 0) !== (a.reviewsCount || 0)) {
        return (b2.reviewsCount || 0) - (a.reviewsCount || 0);
      }
      return (b2.rating || 0) - (a.rating || 0);
    }).slice(0, 4);

    var best = bestList.map(function (p, i) {
      return '<button class="bestcard" data-open="' + p.id + '">' +
        '<span class="th">' + imgTag(p.image, p.name, p.brandId, ' loading="lazy"') +
        '<span class="rank">' + pad(i + 1) + '</span>' +
        (p.badge ? '<span class="bg">' + esc(p.badge) + '</span>' : '') + '</span>' +
        '<span class="nm">' + esc(p.name) + '</span></button>';
    }).join('');

    /* 타일 그리드 */
    return '<section class="sec" id="brand-showcase-section"><div class="wrap">' +

      '<div class="headc"><span class="eyebrow">B-Beauty Standard Symbol</span>' +
      '<h2>' + esc(T('showcase.title')) + '</h2><div class="rule"></div>' +
      '<p>' + esc(T('showcase.description')) + '</p></div>' +

      dirbar +

      '<div class="spot">' +
      '<div class="spot-id"><div><span class="en">' + esc(subEn(b)) + '</span>' +
      '<h3>' + esc(b.name) +
      (b.foundedYear ? '<span class="chip">EST. ' + b.foundedYear + '</span>' : '') + '</h3></div>' +
      '<div class="spot-meta">' +
      mallLinks(b, 'chip round brandy', false) +
      '</div></div>' +

      '<p class="spot-quote">“' + esc(b.concept) + '”</p>' +
      '<p class="spot-desc">' + esc(b.description) + '</p>' +

      '<div class="orgbox">' +
      '<div class="oh">🏢 ' + esc(pick('공식 등록 기업 정보 및 위치',
        'Official Registered Company & Location', '官方注册企业信息及位置')) + '</div>' +
      '<p><span style="color:var(--brand);font-weight:700">📍</span><span>' + esc(b.fullAddress || b.location) + '</span></p>' +
      (b.contactPhone ? '<p><span style="color:var(--brand)">📞</span><span>' +
        esc(pick('고객센터', 'Customer Center', '客服中心')) +
        ': <b>' + esc(b.contactPhone) + '</b></span></p>' : '') +
      (b.contactEmail ? '<p><span style="color:var(--brand)">✉</span><span>' +
        esc(pick('이메일', 'Email', '邮箱')) + ': <a href="mailto:' + esc(b.contactEmail) + '">' +
        esc(b.contactEmail) + '</a></span></p>' : '') +
      mallLinks(b, 'mall', true) +
      '</div>' +

      '<div class="sub" style="border-top:none;padding-top:0;margin-top:0">' +
      '<div class="sub-h"><span>Key Bio-Ingredients</span></div>' +
      '<div class="ingtags">' + b.keyIngredients.map(function (i) {
        return '<span class="chip round brandy">' + esc(i) + '</span>';
      }).join('') + '</div></div>' +

      (sig ? '<div class="sub"><div class="sub-h"><span>' + esc(T('showcase.signature_product')) + '</span>' +
        '<span class="note">' + esc(pick('공식몰 기준 가격', 'Official store price', '官方商城价格')) +
        '</span></div>' + sig + '</div>' : '') +

      (best ? '<div class="sub"><div class="sub-h">' +
        '<span>' + esc(pick('BEST 상품', 'Best Sellers', '热销商品')) + '</span>' +
        '<button class="note gobtn" data-shop="' + b.id + '">' +
        esc(pick('전체 ' + bp.length + '종 보기', 'View all ' + bp.length,
          '查看全部 ' + bp.length + ' 款')) + ' →</button></div>' +
        '<div class="bestgrid">' + best + '</div>' +
        priceNote(b.id) + '</div>' : '') +

      '<div class="spot-foot">' +
      '<button class="linkbtn" data-dossier="' + b.id + '">◉ ' + esc(T('showcase.view_history')) + '</button>' +
      '<button class="btn btn-soft" data-shop="' + b.id + '">' + esc(T('showcase.shop_this_brand')) + ' →</button>' +
      '</div></div>' +

      '<div style="margin-top:88px;padding-top:56px;border-top:1px solid var(--line)">' +
      '<div class="headl" style="border:none;padding:0;margin-bottom:32px">' +
      '<div><span class="eyebrow">Brand Films</span>' +
      '<h2 style="font-size:clamp(22px,3.2vw,32px)">' + esc(T('showcase.grid_title')) + '</h2></div>' +
      '<p style="max-width:360px">' + esc(T('showcase.grid_desc')) + '</p></div>' +
      videoDeck() + '</div>' +

      '</div></section>';
  }


  /* =========================================================
     BRAND FILMS — 공식 유튜브 영상 캐러셀
     썸네일을 눌러 재생. 영상이 perPage 보다 많으면 아래 점으로 넘긴다.
     ========================================================= */
  function videoData() { return (window.VIDEOS || {}); }
  function videoList() { return (videoData().videos || []); }
  function videoPerPage() { return videoData().perPage || 3; }
  function videoPages() { return Math.max(1, Math.ceil(videoList().length / videoPerPage())); }

  function videoById(id) {
    return videoList().filter(function (v) { return v.id === id; })[0] || null;
  }
  /* 언어별 문구 — 없으면 한국어로 */
  function vt(v, f) {
    var o = v[f] || {};
    return o[S.lang] || o.KR || '';
  }
  /* 썸네일 — 직접 지정 > 유튜브 자동 > 브랜드 대표 이미지 */
  function videoThumb(v) {
    if (v.thumbnail) return img(v.thumbnail);
    if (v.youtubeId) return 'https://img.youtube.com/vi/' + encodeURIComponent(v.youtubeId) + '/hqdefault.jpg';
    var b = v.brandId ? brandById(v.brandId) : null;
    return img(b ? b.image : (window.HERO_IMAGE || ''));
  }
  function videoBrandLabel(v) {
    var b = v.brandId ? brandById(v.brandId) : null;
    return b ? b.name : pick('B-Beauty 연합', 'B-Beauty Alliance', 'B-Beauty 联合');
  }
  var VIDEO_KIND = {
    promo: ['홍보 영상', 'Brand Film', '品牌宣传'],
    event: ['이벤트 안내', 'Event Guide', '活动介绍'],
    interview: ['인터뷰', 'Interview', '访谈'],
    guide: ['사용법', 'How-to', '使用指南']
  };

  function videoDeck() {
    var all = videoList();
    if (!all.length) return '';

    var per = videoPerPage();
    var pages = videoPages();
    var page = Math.min(S.vidPage, pages - 1);
    var slice = all.slice(page * per, page * per + per);

    var cards = slice.map(function (v) {
      var ready = !!v.youtubeId;
      var kind = VIDEO_KIND[v.kind] || VIDEO_KIND.promo;
      return '<' + (ready ? 'button' : 'div') + ' class="vcard' + (ready ? '' : ' soon') + '"' +
        (ready ? ' data-video="' + esc(v.id) + '"' : '') + '>' +
        '<div class="vthumb"><img src="' + esc(videoThumb(v)) + '" alt="' + esc(vt(v, 'title')) + '" loading="lazy">' +
        '<span class="vsh"></span>' +
        (ready ? '<span class="vplay" aria-hidden="true">▶</span>'
               : '<span class="vsoon">' + esc(pick('영상 준비 중', 'Coming soon', '视频筹备中')) + '</span>') +
        '</div>' +
        '<div class="vbody">' +
        '<div class="vmeta"><span class="vbrand">' + esc(videoBrandLabel(v)) + '</span>' +
        '<span class="vkind">' + esc(L(kind)) + '</span>' +
        (v.date ? '<span class="vdate">' + esc(v.date) + '</span>' : '') + '</div>' +
        '<h4>' + esc(vt(v, 'title')) + '</h4>' +
        (vt(v, 'desc') ? '<p>' + esc(vt(v, 'desc')) + '</p>' : '') +
        '</div>' +
        '</' + (ready ? 'button' : 'div') + '>';
    }).join('');

    var dots = pages > 1 ? '<div class="vdots" role="tablist">' +
      Array.apply(null, Array(pages)).map(function (_, i) {
        return '<button class="vdot' + (i === page ? ' on' : '') + '" data-vpage="' + i + '"' +
          ' aria-label="' + esc(pick('영상 묶음 ', 'Video page ', '视频组 ') + (i + 1)) + '"></button>';
      }).join('') + '</div>' : '';

    var ch = videoData().channelUrl;
    var link = ch ? '<a class="vchannel" href="' + esc(ch) + '" target="_blank" rel="noopener">' +
      esc(pick('공식 유튜브 채널 ', 'Official YouTube channel ', '官方 YouTube 频道 ')) + '↗</a>' : '';

    /* 좌우 화살표 — 카드 양옆. 끝에 닿으면 흐려지고 눌리지 않는다 */
    var nav = pages > 1 ?
      '<button class="vnav prev" data-vnav="prev"' + (page === 0 ? ' disabled' : '') +
      ' aria-label="' + esc(pick('이전 영상', 'Previous videos', '上一组视频')) + '">‹</button>' +
      '<button class="vnav next" data-vnav="next"' + (page === pages - 1 ? ' disabled' : '') +
      ' aria-label="' + esc(pick('다음 영상', 'Next videos', '下一组视频')) + '">›</button>' : '';

    return '<div class="vstage">' + nav +
      '<div class="vdeck" id="video-deck">' + cards + '</div></div>' + dots + link;
  }

  /* 영상 페이지 이동 — 범위를 벗어나면 무시 */
  function videoGo(step) {
    var pages = videoPages();
    var next = Math.min(Math.max(S.vidPage + step, 0), pages - 1);
    if (next === S.vidPage) return;
    S.vidPage = next; render();
  }

  /* 영상 재생 모달 */
  function videoModal() {
    if (!S.video) return '';
    var v = videoById(S.video);
    if (!v || !v.youtubeId) return '';
    var src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(v.youtubeId) +
      '?autoplay=1&rel=0&modestbranding=1';
    return '<div class="overlay" data-close="video"><div class="sheet w3" role="dialog" aria-modal="true">' +
      '<div class="sheet-bar"><span>' + esc(videoBrandLabel(v)) + '</span>' +
      '<button class="xbtn" data-close="video">✕</button></div>' +
      '<div class="sheet-body">' +
      '<div class="vframe"><iframe src="' + esc(src) + '" title="' + esc(vt(v, 'title')) + '"' +
      ' frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"' +
      ' allowfullscreen></iframe></div>' +
      '<h3 style="margin:18px 0 8px;font-size:18px;font-weight:700">' + esc(vt(v, 'title')) + '</h3>' +
      (vt(v, 'desc') ? '<p style="margin:0;font-size:13.5px;font-weight:400;line-height:1.9;color:var(--brand-mid)">' +
        esc(vt(v, 'desc')) + '</p>' : '') +
      '</div><div class="sheet-foot" style="justify-content:flex-end">' +
      '<a class="btn btn-line" href="https://www.youtube.com/watch?v=' + esc(v.youtubeId) + '"' +
      ' target="_blank" rel="noopener">' + esc(pick('유튜브에서 보기', 'Watch on YouTube', '在 YouTube 观看')) + ' ↗</a>' +
      '<button class="btn btn-solid" data-close="video">' + esc(T('product.close')) + '</button>' +
      '</div></div></div>';
  }

  /* ---------- 브랜드 도씨에 모달 ---------- */
  function dossier() {
    if (!S.dossier) return '';
    var b = brandById(S.brandId);
    var bp = products().filter(function (p) { return p.brandId === b.id; });

    return '<div class="overlay" data-close="dossier"><div class="sheet w4" role="dialog" aria-modal="true">' +
      '<div class="sheet-bar"><span>B-Beauty Brand Archive Dossier</span>' +
      '<button class="xbtn" id="close-dossier" data-close="dossier">✕</button></div>' +

      '<div class="sheet-body">' +
      '<div class="two mid">' +
      '<div class="dhero"><img src="' + img(b.image) + '" alt="' + esc(b.name) + '"></div>' +
      '<div class="dinfo"><span class="en">' + esc(subEn(b)) + '</span>' +
      '<h3>' + esc(b.name) + '</h3>' +
      '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px">' +
      (b.foundedYear ? '<span class="chip">Est. ' + b.foundedYear + '</span>' : '') +
      '<span class="chip">📍 ' + esc(b.location) + '</span></div>' +
      '<p style="font-family:var(--font);font-size:14.5px;font-weight:600;' +
      'color:var(--brand);line-height:1.7;margin:0 0 16px">“' + esc(b.concept) + '”</p>' +
      '<div class="dcontact">' +
      '<p>📍 <b>' + esc(b.fullAddress || b.location) + '</b></p>' +
      (b.contactPhone ? '<p>📞 ' + esc(pick('고객센터', 'Customer Center', '客服中心')) + ': <b>' +
        esc(b.contactPhone) + '</b></p>' : '') +
      (b.contactEmail ? '<p>✉ ' + esc(pick('이메일', 'Email', '邮箱')) + ': <b>' +
        esc(b.contactEmail) + '</b></p>' : '') +
      mallLinks(b, 'dossier-mall', false) +
      '</div></div></div>' +

      '<div><div class="blk">Brand Narrative &amp; History</div>' +
      '<p style="margin:0;font-size:13.5px;font-weight:400;line-height:1.95;color:var(--ink);white-space:pre-line">' +
      esc(b.detailedStory) + '</p></div>' +

      '<div><div class="blk">Brand Philosophy (' +
      esc(pick('브랜드 뷰티 신념', 'Beauty Beliefs', '品牌美学信念')) + ')</div>' +
      '<ul class="philo">' + b.philosophy.map(function (p, i) {
        return '<li><span class="n">' + (i + 1) + '</span><span>' + esc(p) + '</span></li>';
      }).join('') + '</ul></div>' +

      '<div><div class="blk">Key Bio-Active Extracts</div>' +
      '<div class="bioactive">' + b.keyIngredients.map(function (ing, i) {
        return '<div><span class="ic">💧</span><div><div class="k">Ingredient ' + pad(i + 1) + '</div>' +
          '<div class="v">' + esc(ing) + '</div></div></div>';
      }).join('') + '</div></div>' +

      '<div><div class="blk">Products in Archive (' +
      esc(pick('판매 및 상세 정보', 'Sales & Details', '销售与详细信息')) + ')</div>' +
      '<div class="archgrid">' + bp.map(function (p) {
        return '<div class="arch"><div class="st">' + imgTag(p.image, p.name, p.brandId) +
          '<span class="cap">' + esc(p.capacity) + '</span></div>' +
          '<div class="bd"><div><div class="r1"><span>' + esc(p.category) + '</span>' +
          (p.rating ? '<span class="rt">★ ' + p.rating +
            (p.reviewsCount ? ' (' + p.reviewsCount + ')' : '') + '</span>' : '') + '</div>' +
          '<h5>' + esc(p.name) + '</h5><p class="ds">' + esc(p.description) + '</p></div>' +
          '<div class="r2"><span class="now' + (p.priceOnRequest ? ' ask' : '') + '">' +
          esc(priceText(p)) + '</span>' +
          storeLink(p, 'btn btn-sm btn-sq btn-solid', pick('공식몰', 'Store', '商城')) +
          '</div></div></div>';
      }).join('') + '</div></div>' +

      '</div>' +

      '<div class="sheet-foot"><span class="fnote">' +
      'B-Wave standard alliance keeps strict 100% safety checks.</span>' +
      '<div style="display:flex;flex-wrap:wrap;gap:10px">' +
      mallLinks(b, 'btn btn-line', false) +
      '<button class="btn btn-solid" data-shop="' + b.id + '">' + esc(T('showcase.explore_all')) + ' →</button>' +
      '</div></div></div></div>';
  }

  /* =========================================================
     PRODUCT EXPLORER (ProductExplorer.tsx)
     ========================================================= */
  function filteredProducts() {
    var out = products().slice();
    if (S.brandFilter !== 'All') out = out.filter(function (p) { return p.brandId === S.brandFilter; });
    if (S.category !== 'All') out = out.filter(function (p) { return p.category === S.category; });
    if (S.concern !== 'All') out = out.filter(function (p) { return p.skinConcerns.indexOf(S.concern) > -1; });
    var q = S.query.trim().toLowerCase();
    if (q) {
      out = out.filter(function (p) {
        return p.name.toLowerCase().indexOf(q) > -1 ||
          p.englishName.toLowerCase().indexOf(q) > -1 ||
          p.description.toLowerCase().indexOf(q) > -1 ||
          p.ingredients.some(function (i) { return i.toLowerCase().indexOf(q) > -1; });
      });
    }
    if (S.sort === 'price-asc') out.sort(function (a, b) { return a.price - b.price; });
    else if (S.sort === 'price-desc') out.sort(function (a, b) { return b.price - a.price; });
    else if (S.sort === 'rating') out.sort(function (a, b) { return b.rating - a.rating; });
    return out;
  }

  function productCard(p) {
    return '<article class="pcard" id="product-card-' + p.id + '" data-open="' + p.id + '">' +
      '<div class="pstage">' + imgTag(p.image, p.name, p.brandId, ' loading="lazy"') +
      '<div class="veil"></div>' +
      '<span class="btag">' + esc(p.brandName) + '</span>' +
      (p.badge ? '<span class="bdg"><span class="badge' +
        (p.badge === 'SET' ? ' set' : (p.badge === 'BEST' ? ' gold' : '')) + '">' +
        esc(p.badge) + '</span></span>' : '') +
      '<span class="cap">' + esc(p.capacity) + '</span>' +
      (p.vegan ? '<span class="veg">VEGAN</span>' : '') +
      '</div>' +
      '<div class="pbody"><div>' +
      '<div class="pmeta"><span>' + esc(catLabel(p.category)) + '</span>' +
      (p.rating ? '<span class="rt">★<b>' + p.rating + '</b></span>' : '') + '</div>' +
      '<h3>' + esc(p.name) + '</h3>' +
      '<p class="pdesc">' + esc(p.description) + '</p>' +
      '<div class="tags">' + p.ingredients.slice(0, 2).map(function (i) {
        return '<span>#' + esc(i) + '</span>';
      }).join('') + '</div></div>' +
      '<div class="pfoot"><span class="pricecol">' +
      (p.originalPrice && !p.priceOnRequest ? '<span class="was">' + won(p.originalPrice) + '</span>' : '') +
      '<span class="now' + (p.priceOnRequest ? ' ask' : '') + '">' + esc(priceText(p)) + '</span>' +
      (p.memberPrice ? '<span class="memnote">' +
        esc(pick('회원가 별도', 'Member price', '会员价另议')) + '</span>' : '') +
      (p.freeShipping ? '<span class="freeship">' +
        esc(pick('무료배송', 'Free shipping', '免运费')) + '</span>' : '') +
      '</span>' +
      '<span class="cta" data-stop="1">' +
      storeLinks(p, 'btn btn-sm btn-sq btn-solid') +
      '</span></div></div></article>';
  }

  function viewProducts() {
    var list = filteredProducts();
    var ab = S.brandFilter === 'All' ? null : brandById(S.brandFilter);

    var brandTabs = '<div class="dirbar"><div class="dl">BRAND / ' +
      esc(pick('브랜드 소분류', 'Sub-category', '品牌分类')) + '</div><div class="dp">' +
      '<button class="dirpill' + (S.brandFilter === 'All' ? ' on' : '') + '" data-bf="All">' +
      esc(T('products.all_brands')) + '</button>' +
      brands().map(function (b) {
        return '<button class="dirpill' + (S.brandFilter === b.id ? ' on' : '') + '" data-bf="' + b.id + '">' +
          '<span>' + esc(b.name) + '</span><span class="en">' + esc(subEn(b)) + '</span></button>';
      }).join('') + '</div></div>';

    var main = '<div>' +
      '<div class="cattabs">' + CATEGORIES.map(function (c) {
        return '<button class="cattab' + (S.category === c ? ' on' : '') + '" data-cat="' + c + '">' +
          esc(catLabel(c)) + '</button>';
      }).join('') + '</div>' +
      '<div class="concerns"><span class="cl">Skin Concern:</span>' +
      CONCERNS.map(function (c) {
        return '<button class="conpill' + (S.concern === c ? ' on' : '') + '" data-con="' + esc(c) + '">' +
          esc(conLabel(c)) + '</button>';
      }).join('') + '</div>' +
      '<div class="countrow"><span>FOUND ' + list.length + ' PREMIUM ITEMS</span>' +
      (ab ? '<span>Brand Filter: <strong>' + esc(ab.name) + '</strong></span>' : '') + '</div>' +
      (list.length ? '<div class="grid">' + list.map(productCard).join('') + '</div>'
        : '<div class="empty"><div class="ic">◌</div>' +
        '<h4>' + esc(T('products.no_results')) + '</h4>' +
        '<p>' + esc(pick('검색어나 피부 고민 필터를 다르게 조절해 보시길 권장합니다.',
          'We suggest adjusting your search keywords or skin concern filters.',
          '建议您调整搜索词或肌肤问题筛选条件重新查找。')) + '</p>' +
        '<button class="btn btn-solid" id="clear-all-filters">' + esc(T('products.clear_all_filters')) + '</button></div>') +
      '</div>';

    return '<section class="sec view" id="product-explorer-section"><div class="wrap">' +
      '<div class="headl"><div><span class="eyebrow">B-Beauty Platform Shop</span>' +
      '<h2>B-Wave Products</h2><p>' + esc(T('products.description')) + '</p></div>' +
      '<div style="width:100%;max-width:330px">' + searchBox('prod', 'full') + '</div></div>' +
      brandTabs +
      '<div class="explorer">' + main + '</div>' +
      priceNote(S.brandFilter === 'All' ? '' : S.brandFilter) +
      '</div></section>';
  }

  /* ---------- 제품 상세 모달 ---------- */
  function productModal() {
    if (!S.activeProduct) return '';
    var p = productById(S.activeProduct); if (!p) return '';

    return '<div class="overlay" data-close="product"><div class="sheet w3" role="dialog" aria-modal="true">' +
      '<div class="sheet-bar"><span>B-Beauty Product Dossier</span>' +
      '<button class="xbtn" id="close-product-modal" data-close="product">✕</button></div>' +
      '<div class="sheet-body">' +
      '<div class="two top">' +
      '<div><div class="mstage">' + imgTag(p.image, p.name, p.brandId) + '</div>' +
      '<div class="mrow"><span>' + esc(T('product.capacity')) + ': ' + esc(p.capacity) + '</span>' +
      '<span style="display:flex;flex-wrap:wrap;gap:6px">' +
      (p.vegan ? '<span class="chip round green">VEGAN</span>' : '') +
      (p.skinConcerns && p.skinConcerns.length
        ? p.skinConcerns.map(function (c) {
            return '<span class="chip round brandy">' + esc(conLabel(c)) + '</span>';
          }).join('')
        : '<span class="chip round">' + esc(brandById(p.brandId).name) + '</span>') +
      '</span></div></div>' +
      '<div class="minfo"><div><span class="bn">' + esc(p.brandName) + ' (' + esc(p.brandId) + ')</span>' +
      '<h3>' + esc(p.name) +
      '</h3><p class="en">' + esc(p.englishName) + '</p></div>' +
      '<div class="pricebar"><div class="col"><span class="k">' +
      esc(p.memberPrice ? pick('소비자가', 'List Price', '建议零售价') : 'Selling Price') + '</span>' +
      (p.originalPrice && !p.priceOnRequest ? '<span class="was">' + won(p.originalPrice) + '</span>' : '') +
      '<span class="v">' + esc(priceText(p)) + '</span></div>' +
      '<div class="div"></div>' +
      (p.rating ? '<div class="col"><span class="k">Consumer Rating</span>' +
        '<span class="rr">★ ' + p.rating + ' / 5.0' +
        (p.reviewsCount ? ' <small>(' + p.reviewsCount + ' reviews)</small>' : '') + '</span>' : '<div class="col">') +
      (p.freeShipping ? '<span class="freeship" style="margin-top:4px">' +
        esc(pick('무료배송', 'Free shipping', '免运费')) + '</span>' : '') + '</div></div>' +
      '<p style="margin:0;font-size:13.5px;font-weight:400;line-height:1.9;color:var(--ink)">' +
      esc(p.detailedDescription) + '</p></div></div>' +

      (p.benefits && p.benefits.length
        ? '<div class="benefits"><h4>✓ ' + esc(T('product.benefits')) + '</h4><ul>' +
          p.benefits.map(function (b) { return '<li><span>' + esc(b) + '</span></li>'; }).join('') +
          '</ul></div>'
        : '') +

      (p.ingredients && p.ingredients.length
        ? '<div><div class="blk">' + esc(T('product.ingredients')) + '</div>' +
          '<div class="ingrid">' + p.ingredients.map(function (i) {
            return '<div><span class="n">' + esc(i) + '</span><span class="c">EWG Green</span></div>';
          }).join('') + '</div></div>'
        : '<div class="notebox" style="border-radius:14px">' +
          '<span>ⓘ</span><span>' + esc(pick(
            '전성분과 상세 사양은 공식몰 상품 페이지에서 확인하실 수 있습니다.',
            'Full ingredients and specifications are available on the official store page.',
            '全成分与详细规格请前往官方商城商品页查看。')) + '</span></div>') +

      (function () {
        var b = brandById(p.brandId);
        if (!b || (!b.officialUrl && !b.storeUrl)) return '';
        var btn = function (url, label) {
          return '<a class="btn btn-line" style="margin-top:10px" href="' + esc(url) +
            '" target="_blank" rel="noopener">' + esc(label) + ' ↗</a>';
        };
        return '<div><div class="blk">' +
          esc(pick('구매처', 'Where to buy', '购买渠道')) + '</div>' +
          priceNote(p.brandId) +
          '<div style="display:flex;flex-wrap:wrap;gap:10px">' +
          (b.officialUrl ? btn(b.officialUrl,
            pick('공식몰에서 보기', 'Official store', '前往官方商城')) : '') +
          (b.storeUrl ? btn(b.storeUrl,
            pick('스마트스토어에서 보기', 'Naver Smart Store', '前往 Naver 商城')) : '') +
          '</div></div>';
      })() +
      '</div>' +
      '<div class="sheet-foot"><span class="fnote">' +
      esc(pick('구매와 결제는 각 브랜드 공식몰에서 진행됩니다.',
        'Purchases are completed on each brand official store.',
        '购买与结算请在各品牌官方商城完成。')) + '</span>' +
      storeLink(p, 'btn btn-solid',
        p.priceOnRequest ? pick('공식몰에서 가격 문의', 'Ask price on official store', '前往官方商城咨询价格')
                         : pick('공식몰에서 구매하기', 'Buy on official store', '前往官方商城购买')) +
      '</div></div></div>';
  }

  /* =========================================================
     EVENTS & NOTICES (CompassQuiz.tsx)
     ========================================================= */
  function eventsData() {
    return [
      {
        id: 'quiz', img: '/src/assets/images/ocean_cosmetics_hero_1784622126081.jpg', feature: true, endsAt: null, pop: 'POPULAR', hi: true, ic: '◎', icColor: 'var(--brand)', catColor: 'var(--brand)',
        cat: 'INTERACTIVE CUSTOM EVENT', stub: false,
        title: pick('나만의 뷰티 파동 찾기 (Beauty Compass)', 'Beauty Compass (Skincare Finder)', '寻找我的专属美肌罗盘'),
        desc: pick('부산의 5대 로컬 럭셔리 브랜드 중, 지금 내 피부 상태와 선호 아로마 향, 웰니스 철학에 완벽히 매칭되는 시그니처 표준 라인을 제안합니다. 진단만 마쳐도 특별 맞춤 추천 제품을 즉시 확인하실 수 있습니다.',
          'Discover which of Busan\'s five premium local brands matches your skin conditions, scent preferences, and wellness values. Get immediate custom recommendations.',
          '在釜山五大高端本土品牌中，寻找完美契合您当前肌肤状况、芳疗偏好及生活哲学的经典护肤系列。测试完毕即可获得定制单品推荐。'),
        period: pick('상시 참여 가능', 'Always Available', '支持随时参与'),
        btn: pick('무료 매칭 진단 받기', 'Start Skincare Finder', '免费获取配对诊断'), act: 'quiz', btnCls: 'btn-solid'
      },
      {
        id: 'voucher', img: '/src/assets/images/healmar_group_1784608608346.jpg', feature: true, endsAt: '2026-12-31', pop: null, ic: '🏅', icColor: 'var(--gold)', catColor: 'var(--gold)',
        cat: 'PROMOTION BENEFIT', stub: true,
        title: pick('첫 가입 웰컴 15% 럭셔리 할인 바우처', 'Welcome 15% Luxury Discount Voucher', '新人注册专属 15% 奢美折扣券'),
        desc: pick('B-Beauty 연합 쇼핑몰 공식 오픈을 기념하여, 생애 첫 구매를 진행하시는 귀빈 고객님들을 위해 15% 파격 한도 즉시 할인 쿠폰을 발급해 드립니다. 전 브랜드 에센셜 라인에 사용이 가능합니다.',
          'To celebrate the grand opening of B-Beauty online alliance store, we issue an immediate 15% discount welcome coupon for your first purchase. Valid across all brands.',
          '为庆祝 B-Beauty 釜山联合商场官方上线，凡首次购买的贵宾顾客均可获赠 15% 封顶优惠券。支持全品牌系列产品。'),
        period: '~ 2026.12.31',
        btn: S.coupon ? pick('다운로드 완료', 'Downloaded', '已成功下载') : pick('바우처 다운받기', 'Download Voucher', '下载优惠券'),
        act: 'coupon', btnCls: 'btn-gold'
      },
      {
        id: 'showroom', img: '/src/assets/images/ldara_group_shot_1784609249679.jpg', feature: true, endsAt: null, pop: null, ic: '🎁', icColor: 'var(--brand)', catColor: 'var(--brand-mid)',
        cat: 'OFFLINE SHOWROOM', stub: false,
        title: pick('광안리 플래그십 그랜드 오프닝 기프트', 'Gwangalli Sunset Flagship Opening Gift', '广安里旗舰店盛大开业奢华礼遇'),
        desc: pick('오프라인 쇼룸에 방문하여 모바일 화면을 제시하시는 분들 중 선착순 100명에게, "엘다라 순금 동백 멀티밤" 정품과 "힐마르 펩타이드 에센스" 트래블 미니어처 3종 키트를 증정합니다.',
          'First 100 guests to visit our Gwangalli Sunset Flagship and present this screen will receive a free full-size "L\'DARA Camellia Multi-Balm" and "Healmar Peptide Essence" 3-piece travel kit.',
          '到访线下展厅并展示此移动端界面的前 100 名贵客，将免费获赠“艾达拉黄金山茶万能膏”正装及“Healmar多肽精华”旅行装三件套。'),
        period: pick('선착순 100명 소진 시 마감', 'First-come 100 users', '限量100份 领完即止'),
        btn: pick('상세정보 확인', 'Check Details', '查看活动详情'), act: 'detail:showroom', btnCls: 'btn-line'
      },
      {
        id: 'eco', img: '/src/assets/images/doubley_group_1784609743977.jpg', feature: false, endsAt: null, pop: null, ic: '🌿', icColor: 'var(--emerald)', catColor: 'var(--emerald)',
        cat: 'SUSTAINABLE ECO CAMPAIGN', stub: false,
        title: pick('친환경 에코 공병 수거 리워드 캠페인', 'Eco Empty Bottles Return Reward', '绿色低碳空瓶回收环保企划'),
        desc: pick('지속 가능한 청정 부산의 바다를 보존하기 위해 화장품 빈 병을 수거합니다. 브랜드 상관없이 사용하신 공병을 쇼룸에 가져오시면, 숲의 사랑 아로마 바디 오일 15ml 체험 샘플과 유기농 린넨 파우치를 선물합니다.',
          'To protect Busan\'s marine ecosystem, return any empty cosmetic container to our showroom. Receive a free "숲의 사랑 Body Oil 15ml" sample and organic linen pouch.',
          '为保护纯净美丽的釜山海洋生态，我们将回收各类化妆品空瓶。将任意空瓶送至线下门店即可获赠“숲의 사랑香薰身体油15ml”旅行装及有机棉麻收纳袋。'),
        period: pick('연중 상시 진행', 'Year-round', '全年常设项目'),
        btn: pick('캠페인 안내', 'Eco Policy', '环保政策指南'), act: 'detail:eco', btnCls: 'btn-line'
      },
      {
        id: 'serum', img: '/src/assets/images/schonu_group_1784608854968.jpg', feature: false, endsAt: '2026-08-20', pop: 'NEW', ic: '✦', icColor: 'var(--cyan)', catColor: 'var(--cyan)',
        cat: 'LIMITED SAMPLING', stub: false,
        title: pick('슌유 마린 바이오 세럼 체험단', 'Schön:U Marine Bio Serum Trial', 'Schön:U 海洋生物精华体验团'),
        desc: pick('부산 해양 심층수와 마린 콜라겐 추출물이 선사하는 고농축 수분 탄력 파동을 가장 먼저 경험해 보세요. 신청자 중 50분을 추첨하여 정품 체험 키트를 보내드립니다.',
          'Be the first to experience high-potency moisture bounce powered by Busan deep sea water and marine collagen. 50 winners receive a free full-size kit.',
          '抢先体验釜山深层海水与海洋胶原蛋白提取物带来的高浓度水润弹力感。我们将随机抽取50位申请者赠送正装体验礼盒。'),
        period: '2026.08.01 ~ 08.20',
        btn: pick('상세정보 확인', 'Check Details', '查看活动详情'), act: 'detail:serum', btnCls: 'btn-line'
      },
      {
        id: 'spa', img: '/src/assets/images/ldara_rose_oil_1784609216945.jpg', feature: false, endsAt: null, pop: 'VIP', ic: '♛', icColor: 'var(--purple)', catColor: 'var(--purple)',
        cat: 'VIP INVITATION', stub: false,
        title: pick('B-Beauty 웰니스 스파 리추얼 주말 초대권', 'B-Beauty Wellness Spa Ritual Weekend Ticket', 'B-Beauty 尊享 SPA 水疗周末邀请函'),
        desc: pick('송정 해비타트 쇼룸 스파에서 경험하는 1:1 맞춤형 메디컬 페이셜 테라피. 연합 쇼핑몰 구매 고객을 대상으로 추첨을 통해 프리미엄 60분 맞춤 스파 이용권을 선물합니다.',
          '1:1 custom facial therapy at Songjeong Habitat Showroom Spa. Purchase customers are entered into a draw for a complimentary 60-minute premium spa voucher.',
          '在松亭展厅 SPA 馆体验 1:1 定制医学级面部理疗。凡在联合商城下单顾客均可参与抽奖，赢取60分钟尊享定制理疗体验券。'),
        period: pick('매월 말 추첨 발표', 'Monthly Draw', '每月月底公布中奖名单'),
        btn: pick('상세정보 확인', 'Check Details', '查看活动详情'), act: 'detail:spa', btnCls: 'btn-line'
      },
      {
        id: 'newyear', img: '/src/assets/images/sch_jojoba_oil_50_box.jpg', feature: false, endsAt: '2026-02-20',
        pop: null, ic: '🎊', icColor: 'var(--gold)', catColor: 'var(--gold)',
        cat: 'SEASONAL GIFT', stub: false,
        title: pick('설맞이 프리미엄 기프트 세트 기획전', 'Lunar New Year Premium Gift Set Fair', '春节尊享礼盒企划展'),
        desc: pick('설 명절을 맞아 5개 브랜드의 대표 제품을 담은 기프트 세트를 특별가로 선보였던 기획전입니다.',
          'A seasonal fair offering gift sets with signature products from all five brands at special prices.',
          '春节期间以特惠价格推出集合五大品牌明星单品的礼盒企划展。'),
        period: '2026.01.20 ~ 02.20',
        btn: pick('종료된 이벤트', 'Ended', '已结束'), act: 'detail:archive', btnCls: 'btn-line'
      },
      {
        id: 'cherry', img: '/src/assets/images/ama_healmar_mist.jpg', feature: false, endsAt: '2026-04-15',
        pop: null, ic: '🌸', icColor: 'var(--purple)', catColor: 'var(--purple)',
        cat: 'LIMITED EDITION', stub: false,
        title: pick('봄맞이 벚꽃 에디션 한정 패키지', 'Spring Cherry Blossom Limited Package', '春季樱花限定套装'),
        desc: pick('삼락생태공원 벚꽃 시즌에 맞춰 한정 제작한 패키지 디자인으로 선보였던 봄 시즌 기획입니다.',
          'A spring edition with limited packaging designed for Busan\'s cherry blossom season.',
          '配合釜山樱花季推出的限定包装春季企划。'),
        period: '2026.03.15 ~ 04.15',
        btn: pick('종료된 이벤트', 'Ended', '已结束'), act: 'detail:archive', btnCls: 'btn-line'
      },
      {
        id: 'parents', img: '/src/assets/images/ama_healmar_serum.jpg', feature: false, endsAt: '2026-05-12',
        pop: null, ic: '🌷', icColor: 'var(--red)', catColor: 'var(--red)',
        cat: 'FAMILY MONTH', stub: false,
        title: pick('가정의 달 감사 기프트 캠페인', 'Family Month Appreciation Gift Campaign', '家庭月感恩礼遇企划'),
        desc: pick('가정의 달을 맞아 선물용 포장과 손글씨 카드를 무료로 제공했던 캠페인입니다.',
          'Free gift wrapping and handwritten cards offered throughout Family Month in May.',
          '五月家庭月期间免费提供礼品包装与手写贺卡的活动。'),
        period: '2026.05.01 ~ 05.12',
        btn: pick('종료된 이벤트', 'Ended', '已结束'), act: 'detail:archive', btnCls: 'btn-line'
      },
      {
        id: 'expo', img: '/src/assets/images/unb_group_1784621702343.jpg', feature: false, endsAt: '2026-05-31',
        pop: null, ic: '🏛', icColor: 'var(--brand)', catColor: 'var(--brand)',
        cat: 'OFFLINE EXHIBITION', stub: false,
        title: pick('부산 벡스코 뷰티 엑스포 공동 부스 참가', 'Joint Booth at BEXCO Busan Beauty Expo', '釜山 BEXCO 美容博览会联合展位'),
        desc: pick('연합 5개 브랜드가 공동 부스를 열고 제품 시연과 현장 체험을 진행했던 전시입니다.',
          'The five alliance brands ran a joint booth with product demos and on-site trials.',
          '联盟五大品牌联合设展，现场进行产品演示与体验。'),
        period: '2026.05.21 ~ 05.24',
        btn: pick('종료된 이벤트', 'Ended', '已结束'), act: 'detail:archive', btnCls: 'btn-line'
      },
      {
        id: 'scalp', img: '/src/assets/images/ldara_shampoobar_yellow_1784609184569.jpg', feature: false, endsAt: '2026-06-30',
        pop: null, ic: '🌾', icColor: 'var(--emerald)', catColor: 'var(--emerald)',
        cat: 'CARE WEEK', stub: false,
        title: pick('두피 케어 위크 샴푸바 체험 기획', 'Scalp Care Week Shampoo Bar Trial', '头皮护理周洗发皂体验企划'),
        desc: pick('환절기 두피 관리를 주제로 샴푸바 미니어처를 체험해 볼 수 있었던 기간 한정 기획입니다.',
          'A limited-run program offering shampoo bar miniatures for seasonal scalp care.',
          '以换季头皮护理为主题，限时提供洗发皂小样体验。'),
        period: '2026.06.10 ~ 06.30',
        btn: pick('종료된 이벤트', 'Ended', '已结束'), act: 'detail:archive', btnCls: 'btn-line'
      },
      {
        id: 'summer', img: '/src/assets/images/doubley_suncream.jpg', feature: false, endsAt: '2026-07-31',
        pop: null, ic: '☀', icColor: 'var(--cyan)', catColor: 'var(--cyan)',
        cat: 'SUMMER CAMPAIGN', stub: false,
        title: pick('여름 해변 자외선 차단 캠페인', 'Summer Beach Sun Care Campaign', '夏日海滩防晒企划'),
        desc: pick('해운대·광안리 해변 방문객을 대상으로 선크림 샘플과 자외선 지수 안내를 제공했던 캠페인입니다.',
          'Sunscreen samples and UV index guidance offered to visitors at Haeundae and Gwangalli beaches.',
          '面向海云台、广安里海滩游客提供防晒霜小样与紫外线指数提示。'),
        period: '2026.07.01 ~ 07.31',
        btn: pick('종료된 이벤트', 'Ended', '已结束'), act: 'detail:archive', btnCls: 'btn-line'
      },
      {
        id: 'popup', img: '/src/assets/images/sch_bodywash_lemon_2ea.jpg', feature: false, endsAt: '2025-11-30',
        pop: null, ic: '🏬', icColor: 'var(--brand-mid)', catColor: 'var(--brand-mid)',
        cat: 'POP-UP STORE', stub: false,
        title: pick('서면 팝업스토어 첫 오픈 기념 행사', 'Seomyeon Pop-up Store Opening Event', '西面快闪店首次开业纪念活动'),
        desc: pick('연합 결성 이후 처음으로 열었던 팝업스토어에서 전 브랜드 제품을 한자리에 선보였습니다.',
          'The alliance\'s first pop-up store, showcasing products from every brand in one place.',
          '联盟成立后首次开设的快闪店，集中展示全品牌产品。'),
        period: '2025.11.10 ~ 11.30',
        btn: pick('종료된 이벤트', 'Ended', '已结束'), act: 'detail:archive', btnCls: 'btn-line'
      }
    ];
  }

  var EV_DETAIL = {
    showroom: function () {
      return {
        eyebrow: 'Offline Event Specification', color: 'var(--brand)',
        title: pick('광안리 선셋 & 송정 쇼룸 그랜드 오프닝', 'Gwangalli Sunset & Songjeong Grand Opening', '广安里 & 松亭线下展厅隆重开业开店礼遇'),
        lead: pick('B-Beauty 연합 공식 런칭을 축하하며, 부산의 가장 빛나는 해안가 팝업 로드샵 매장을 방문해주시는 고객 분들께 준비한 스페셜 기프트 교환권 행사입니다.',
          'To celebrate B-Beauty official grand opening, we provide special exchange gift kits for guests who visit our premium offline Gwangalli and Songjeong showrooms.',
          '为庆祝 B-Beauty 品牌官方上线，我们将针对到访釜山最耀眼的海岸线快闪实体店的贵宾顾客，限时发放特别尊贵伴手礼。'),
        kt: '🎁 ' + pick('사은품 구성:', 'Trial Kit Includes:', '礼包构成：'),
        items: [
          pick('엘다라 선셋 카멜리아 멀티밤 정품 (10g)', 'L\'DARA Camellia Glow Multi-Balm Full-size (10g)', '艾达拉山茶万能滋润膏正装 (10g)'),
          pick('힐마르 바이오 리포좀 콜라겐 앰플 트래블 3P', 'Healmar Peptide Liposome Collagen Ampoule 3ea', 'Healmar多肽脂质体青春安瓶旅行装 3支'),
          pick('시에스킨 갈대 크림 미니 샤셰 파우치', 'CIESKIN Cieskin G9 Cream Travel Sachet', 'CIESKIN舒缓再生霜迷你袋装')
        ],
        nk: pick('참여방법:', 'How to participate:', '参与方式：'),
        note: pick('본 모바일 화면 혹은 B-Beauty 회원 런칭 이메일을 오프라인 점원에게 보여주시면 즉시 수령 완료!',
          'Show this mobile screen or welcome email to showroom staff to redeem your grand opening gift immediately.',
          '线下展厅向店员出示该移动页面或开业注册邮件，即可立刻免费兑换！')
      };
    },
    eco: function () {
      return {
        eyebrow: 'Sustainable Policy', color: 'var(--emerald)',
        title: pick('에코 공병 리사이클 캠페인', 'Eco Empty Container Recycling', '空瓶绿色环保回收企划'),
        lead: pick('B-Beauty는 기수역 청정 갈대, 혹한의 동백나무 등 부산의 해안 생태계로부터 귀중한 천연 바이오 활성 원료를 공급받고 있습니다. 우리의 빚을 지구와 아름답게 공유하기 위해 공병 수거 리워드 캠페인을 실천합니다.',
          'B-Beauty sources raw natural compounds from clean, wild camellias and coastal reeds. To repay our debt to nature, we implement empty cosmetic container returns.',
          'B-Beauty 深度提取釜山清洁湿地芦苇、耐寒红山茶等釜山海岸自然生态中的珍贵纯净原料。为回馈自然并呵护地球，我们常年开展空瓶回收兑礼。'),
        kt: '🌱 ' + pick('리워드 증정:', 'Reward Offers:', '环保回报：'),
        items: [
          pick('숲의 사랑 바디 앤 마인드 아로마 오일 트래블 (15ml)', '숲의 사랑 Forest Love Aromatherapy Body Oil (15ml)', '숲의 사랑植物杀菌素香薰身体油 (15ml)'),
          pick('100% 무형광 친환경 린넨 웰니스 에코백', '100% Unbleached Organic Cotton Linen Pouch', '100%无荧光环保棉麻素雅收纳袋'),
          pick('B-Beauty 온라인 샵 즉시 사용 2,000 포인트', '2,000 store points to use instantly', 'B-Beauty在线商城无门槛2,000积分')
        ],
        nk: pick('주의사항:', 'Precaution:', '温馨提示：'),
        note: pick('깨끗하게 내부를 세척한 유리/플라스틱 화장품 공병이면 타 브랜드 상품도 전량 수거 및 리워드 적용을 해드립니다.',
          'Any brand\'s empty glass or plastic cosmetic bottles are accepted if washed and cleaned before return.',
          '内部清洗干净的玻璃或塑料化妆品空瓶均可回收，即使是非B-Beauty旗下的其他品牌空瓶也能获得返现和赠品！')
      };
    },
    serum: function () {
      return {
        eyebrow: 'Limited Sampling Trial', color: 'var(--cyan)',
        title: pick('슌유 마린 바이오 세럼 체험단', 'Schön:U Marine Bio Serum Trial', 'Schön:U 海洋生物精华体验团'),
        lead: pick('부산 해양 심층수와 마린 콜라겐 추출물이 선사하는 고농축 수분 탄력 세럼을 누구보다 먼저 경험해보세요. 우수 후기 작성자에게는 추가 사은품이 증정됩니다.',
          'Experience high-potency moisture bounce powered by Busan deep sea water and marine collagen. Top reviewers win extra gifts.',
          '抢先体验釜山深层海水与海洋胶原蛋白提取物带来的高浓度水润弹力感。优质评价撰写者将获赠额外精美礼品。'),
        kt: '💧 ' + pick('체험 구성:', 'Kit Content:', '体验礼包：'),
        items: [
          pick('슌유 마린 바이오 콜라겐 세럼 정품 50ml', 'Schön:U Marine Bio Collagen Serum 50ml', 'Schön:U 海洋生物胶原蛋白精华正装 50ml'),
          pick('마린 수딩 마스크 팩 5매 Set', 'Marine Soothing Mask Pack 5ea Set', '海洋舒缓面膜 5片盒装')
        ],
        nk: pick('신청안내:', 'Application:', '申请指南：'),
        note: pick('B-Beauty 회원 로그인 후 신청하기 버튼을 누르면 자동 응모됩니다. 당첨자는 개별 SMS 안내 드립니다.',
          'Log in to B-Beauty to apply. Winners will be notified via SMS.',
          '登录B-Beauty会员后点击申请按钮即可自动参与。中奖者将通过短信单独通知。')
      };
    },
    spa: function () {
      return {
        eyebrow: 'VIP Spa Invitation', color: 'var(--purple)',
        title: pick('B-Beauty 웰니스 스파 리추얼 초대권', 'B-Beauty Wellness Spa Ritual Ticket', 'B-Beauty 尊享 SPA 水疗邀请函'),
        lead: pick('송정 해비타트 쇼룸 스파에서 경험하는 1:1 맞춤형 메디컬 페이셜 테라피 초대 이벤트입니다. 바다의 평온함과 함께 최고급 아로마 리추얼을 경험하세요.',
          '1:1 custom facial therapy at Songjeong Habitat Showroom Spa. Enjoy luxury aromatherapy with soothing sea views.',
          '在松亭展厅 SPA 馆体验 1:1 定制医学级面部理疗邀请活动。在沉静大海的拥抱中体验高端香薰水疗。'),
        kt: '👑 ' + pick('VIP 혜택:', 'VIP Benefit:', 'VIP 权益：'),
        items: [
          pick('60분 맞춤 메디컬 페이셜 & 숄더 아로마 테라피', '60-min Custom Facial & Shoulder Aroma Therapy', '60分钟定制医学面部及肩颈香薰水疗'),
          pick('프라이빗 라운지 웰컴 오가닉 티 & 파티쉐 디저트', 'Private Lounge Welcome Organic Tea & Dessert', '私享休息室迎宾有机茶饮与精美甜点')
        ],
        nk: pick('당첨안내:', 'Draw:', '中奖公布：'),
        note: pick('매월 말 구매 고객 대상 추첨으로 당첨자를 발표하며, 개별 연락처로 초대권을 발송해 드립니다.',
          'Winners are drawn monthly among purchasing customers and receive the invitation individually.',
          '每月月底在下单顾客中抽奖，中奖者将单独收到邀请函。')
      };
    }
  };

  function eventDetailModal() {
    if (!S.evDetail || !EV_DETAIL[S.evDetail]) return '';
    var d = EV_DETAIL[S.evDetail]();
    return '<div class="overlay" data-close="ev"><div class="sheet w-sm" role="dialog" aria-modal="true">' +
      '<div class="sheet-bar"><span style="color:' + d.color + '">' + esc(d.eyebrow) + '</span>' +
      '<button class="xbtn" data-close="ev">✕</button></div>' +
      '<div class="sheet-body" style="gap:18px">' +
      '<div><h3 style="font-family:var(--font);font-size:23px;font-weight:700;color:var(--ink)">' +
      esc(d.title) + '</h3>' +
      '<div style="width:40px;height:1px;background:' + d.color + ';margin-top:12px"></div></div>' +
      '<p style="margin:0;font-size:13.5px;font-weight:400;line-height:1.9;color:var(--brand-mid)">' +
      esc(d.lead) + '</p>' +
      '<div style="padding:18px;border-radius:14px;background:var(--panel);border:1px solid var(--line)">' +
      '<p style="margin:0 0 10px;font-size:13.5px;font-weight:700;color:var(--ink)">' + esc(d.kt) + '</p>' +
      '<ul style="display:grid;gap:6px;padding-left:20px;list-style:disc">' +
      d.items.map(function (i) {
        return '<li style="font-size:12.5px;font-weight:400;line-height:1.7;color:var(--brand-mid)">' +
          esc(i) + '</li>';
      }).join('') + '</ul>' +
      '<p style="margin:14px 0 0;font-family:var(--font);font-size:11.5px;line-height:1.8;color:var(--brand-mid)">' +
      '<strong style="color:' + d.color + '">' + esc(d.nk) + '</strong> ' + esc(d.note) + '</p></div>' +
      '</div><div class="sheet-foot" style="justify-content:flex-end">' +
      '<button class="btn btn-line" data-close="ev">' + esc(T('product.close')) + '</button></div></div></div>';
  }

  function allNotices() {
    var base = S.lang === 'KR' ? window.NOTICES : (window.NOTICES_TR[S.lang] || window.NOTICES);
    return base;
  }
  function filteredNotices() {
    var q = S.noticeQ.trim().toLowerCase();
    var want = null;
    NOTICE_CATS.forEach(function (c) { if (c.code === S.noticeCat && c.code !== 'All') want = c.kr; });
    return allNotices().filter(function (n) {
      if (want && n.category !== want) return false;
      if (q && (n.title + ' ' + n.content).toLowerCase().indexOf(q) === -1) return false;
      return true;
    });
  }


  /* ── 이벤트 분류 ──────────────────────────────────────
     endsAt 이 지났으면 종료된 이벤트. endsAt 이 null 이면 상시 진행.
     feature: true 인 것 중 종료되지 않은 것만 위쪽 대표 자리에 올린다.
     대표가 종료되면 자동으로 아래 목록으로 내려간다. */
  var EV_FEATURE_MAX = 3;

  function evExpired(e) {
    if (!e.endsAt) return false;
    var today = new Date();
    var t = new Date(e.endsAt + 'T23:59:59');
    return t.getTime() < today.getTime();
  }
  function featuredEvents() {
    return eventsData().filter(function (e) { return e.feature && !evExpired(e); })
      .slice(0, EV_FEATURE_MAX);
  }
  /* 대표에 오르지 못한 것 — 진행중이 먼저, 종료된 것은 뒤에 최근 끝난 순으로 */
  function otherEvents() {
    var top = featuredEvents().map(function (e) { return e.id; });
    return eventsData().filter(function (e) { return top.indexOf(e.id) < 0; })
      .sort(function (a, b) {
        var ea = evExpired(a) ? 1 : 0, eb = evExpired(b) ? 1 : 0;
        if (ea !== eb) return ea - eb;
        if (ea === 1) return String(b.endsAt).localeCompare(String(a.endsAt));
        return 0;
      });
  }


  /* 대표 이벤트 카드 — 사진 · 제목 · 날짜 순.
     카드 전체가 버튼이라 어디를 눌러도 해당 이벤트로 이어진다. */
  function evCard(e) {
    var done = evExpired(e);
    var off = done || (e.act === 'coupon' && S.coupon);
    return '<button class="evc' + (done ? ' done' : '') + '" data-ev="' + e.act + '"' +
      (off ? ' disabled' : '') + '>' +
      '<span class="evc-ph">' +
      '<img src="' + img(e.img) + '" alt="' + esc(e.title) + '" loading="lazy">' +
      (done ? '<span class="pop done">' + esc(pick('종료', 'ENDED', '已结束')) + '</span>'
            : (e.pop ? '<span class="pop">' + e.pop + '</span>' : '')) + '</span>' +
      '<span class="evc-tx">' +
      '<span class="cat" style="color:' + e.catColor + '">' + e.cat + '</span>' +
      '<span class="evc-ti">' + esc(e.title) + '</span>' +
      '<span class="evc-dt">' + esc(e.period) + '</span>' +
      '</span></button>';
  }


  /* 전체 이벤트 모달 — 진행중부터 종료된 것까지 한자리에 */
  function allEventsModal() {
    if (!S.evAll) return '';
    var all = eventsData().slice().sort(function (a, b) {
      var ea = evExpired(a) ? 1 : 0, eb = evExpired(b) ? 1 : 0;
      if (ea !== eb) return ea - eb;
      if (ea === 1) return String(b.endsAt).localeCompare(String(a.endsAt));
      return 0;
    });
    var live = all.filter(function (e) { return !evExpired(e); });
    var done = all.filter(evExpired);

    function row(e) {
      var ended = evExpired(e);
      var off = ended || (e.act === 'coupon' && S.coupon);
      return '<' + (off ? 'div' : 'button') + ' class="allrow' + (ended ? ' done' : '') + '"' +
        (off ? '' : ' data-ev="' + e.act + '"') + '>' +
        '<span class="allrow-th"><img src="' + img(e.img) + '" alt="" loading="lazy"></span>' +
        '<span class="allrow-tx">' +
        '<span class="cat" style="color:' + e.catColor + '">' + e.cat + '</span>' +
        '<span class="allrow-ti">' + esc(e.title) + '</span>' +
        '<span class="allrow-dt">' + esc(e.period) + '</span></span>' +
        '<span class="allrow-st">' +
        (ended ? esc(pick('종료', 'ENDED', '已结束'))
               : (e.act === 'coupon' && S.coupon ? esc(pick('발급 완료', 'Issued', '已领取'))
                                                 : esc(pick('진행중', 'ONGOING', '进行中')))) +
        '</span></' + (off ? 'div' : 'button') + '>';
    }

    function group(label, items) {
      if (!items.length) return '';
      return '<div class="allgrp"><div class="allgrp-hd">' + esc(label) +
        '<span>' + items.length + '</span></div>' + items.map(row).join('') + '</div>';
    }

    return '<div class="overlay flat" data-close="evall">' +
      '<div class="sheet w4 flat" role="dialog" aria-modal="true">' +
      '<div class="sheet-bar"><span>' +
      esc(pick('전체 이벤트', 'All Events', '全部活动')) + ' · ' + all.length +
      '</span><button class="xbtn" data-close="evall">✕</button></div>' +
      '<div class="sheet-body">' +
      group(pick('진행중인 이벤트', 'Ongoing', '进行中活动'), live) +
      group(pick('종료된 이벤트', 'Ended', '已结束活动'), done) +
      '</div><div class="sheet-foot" style="justify-content:flex-end">' +
      '<button class="btn btn-line" data-close="evall">' + esc(T('product.close')) + '</button>' +
      '</div></div></div>';
  }

  var EV_PER_PAGE = 3;   /* 한 줄에 3칸 — 넘치면 아래 숫자로 넘긴다 */

  function viewQuizPage() {
    var evs = eventsData();

    var tabs = '<div class="tabwrap"><div class="tabs' + (S.evTab === 'notices' ? ' b' : '') + '">' +
      '<button class="tab' + (S.evTab === 'events' ? ' on' : '') + '" data-evtab="events">🎁 ' +
      esc(pick('진행중인 이벤트', 'Active Events', '进行中活动')) +
      '<span class="tc">' + evs.length + '</span></button>' +
      '<button class="tab' + (S.evTab === 'notices' ? ' on' : '') + '" data-evtab="notices">🔔 ' +
      esc(pick('공지사항', 'Announcements', '公告通知')) +
      '<span class="tc">' + allNotices().length + '</span></button></div></div>';

    var body;
    if (S.evTab === 'events') {
      if (S.quiz.active) { body = quizPanel(); }
      else {
        /* ── 대표 이벤트 (위) ── */
        body = '<div class="evgrid">' + featuredEvents().map(evCard).join('') + '</div>';

        /* ── 지난 · 그 외 이벤트 (아래) ── */
        var rest = otherEvents();
        if (rest.length) {
          var pastPages = Math.max(1, Math.ceil(rest.length / EV_PER_PAGE));
          if (S.evPage > pastPages) S.evPage = 1;
          var restSlice = rest.slice((S.evPage - 1) * EV_PER_PAGE, S.evPage * EV_PER_PAGE);
          var doneCount = rest.filter(evExpired).length;

          body += '<div class="evpast">' +
            '<div class="evpast-hd"><h3>' +
            esc(pick('지난 이벤트 · 그 외 이벤트', 'Past & Other Events', '往期与其他活动')) + '</h3>' +
            '<button class="cnt" data-evall title="' +
            esc(pick('전체 이벤트 보기', 'View all events', '查看全部活动')) + '">' + rest.length +
            (doneCount ? ' · ' + esc(pick('종료 ', 'ended ', '已结束 ')) + doneCount : '') +
            '<span class="cnt-go">' + esc(pick('전체보기', 'View all', '查看全部')) + ' ›</span></button></div>' +
            '<div class="evpast-rule"></div>' +
            '<div class="evgrid">' + restSlice.map(evCard).join('') + '</div>';

          if (pastPages > 1) {
            var nums = '';
            for (var i = 1; i <= pastPages; i++) {
              nums += '<button class="' + (S.evPage === i ? 'on' : '') + '" data-evpage="' + i + '">' + i + '</button>';
            }
            body += '<div class="pager"><div class="row">' +
              '<button data-evpage="' + (S.evPage - 1) + '"' + (S.evPage === 1 ? ' disabled' : '') + '>‹ ' +
              esc(pick('이전', 'Prev', '上一页')) + '</button>' +
              '<div class="nums">' + nums + '</div>' +
              '<button data-evpage="' + (S.evPage + 1) + '"' + (S.evPage === pastPages ? ' disabled' : '') + '>' +
              esc(pick('다음', 'Next', '下一页')) + ' ›</button></div>' +
              '<span class="info">PAGE ' + S.evPage + ' / ' + pastPages + '</span></div>';
          }
          body += '</div>';
        }
      }
    } else {
      var list = filteredNotices();
      var total = allNotices().length;
      body =
        '<div class="ntoolbar"><div class="ncats">' + NOTICE_CATS.map(function (c) {
          return '<button class="ncat-btn' + (S.noticeCat === c.code ? ' on' : '') + '" data-ncat="' + c.code + '">' +
            esc(L(c.l)) + '</button>';
        }).join('') + '</div>' +
        '<div style="width:100%;max-width:320px"><div class="sbox full">' +
        '<span class="mag">⌕</span><input id="notice-q" value="' + esc(S.noticeQ) + '" placeholder="' +
        esc(pick('공지 제목 또는 내용을 검색하세요...', 'Search announcement contents...',
          '请输入公告标题或内容进行检索...')) + '"></div></div></div>' +

        '<div class="nboard">' +
        '<div class="nboard-hd"><h3>' +
        esc(pick('공지사항', 'Announcements', '公告通知')) + '</h3>' +
        '<span class="cnt">' + list.length + ' / ' + total + '</span></div>' +
        '<div class="nboard-rule"></div>' +

        (list.length ? '<div class="notices">' + list.map(function (n) {
          var open = S.noticeOpen === n.id;
          var cat = S.lang === 'KR' ? n.category : (n.categoryEn || n.category);
          return '<div class="notice' + (open ? ' open' : '') + '">' +
            '<button class="nhead" data-notice="' + n.id + '">' +
            '<span class="nrow1"><span class="qmark">Q.</span>' +
            (n.isImportant ? '<span class="imp">' + esc(pick('중요', 'HOT', '重要')) + '</span>' : '') +
            '<span class="ntag ' + (NOTICE_CLS[n.category] || '') + '">' + esc(cat) + '</span></span>' +
            '<span class="nt">' + esc(n.title) + '</span>' +
            '<span class="nrow2"><span class="nd">' + esc(n.date) + '</span>' +
            '<span class="cv">▼</span></span></button>' +
            (open ? '<div class="nbody"><span class="amark">A.</span><div class="atx">' +
              esc(n.content) +
              '<p class="dt">' + esc(pick('등록일', 'Date', '发布日期')) + ' ' + esc(n.date) +
              (n.sourceUrl ? ' · <a href="' + esc(n.sourceUrl) + '" target="_blank" rel="noopener">' +
                esc(pick('공식몰 원문', 'Original', '原文')) + ' ↗</a>' : '') +
              '</p></div></div>' : '') +
            '</div>';
        }).join('') + '</div>'
          : '<div class="nempty"><span class="ic">◌</span>' +
          esc(pick('검색 결과에 부합하는 공지사항이 존재하지 않습니다.',
            'No announcements found matching the search.', '未检索到符合条件的公告通知。')) + '</div>') +
        '</div>';
    }

    return '<section class="sec view" id="events-notices-section"><div class="wrap-md">' +
      '<div class="headc">' +
      '<h2>' + esc(pick('이벤트 / 공지사항', 'Events & Notice Board', '活动与公告')) + '</h2></div>' +
      tabs + body + '</div></section>';
  }

  /* ---------- 스킨케어 컴퍼스 퀴즈 ---------- */
  function quizPanel() {
    var qs = D().quiz, q = S.quiz;
    var inner = '';

    if (q.step === 'welcome') {
      inner = '<div class="qwelcome">' +
        '<span class="pill-badge" style="margin:0 auto">◎ Skincare Alliance Compass</span>' +
        '<div><h2>' + esc(pick('나만의 뷰티 파동 찾기', 'Find Your Beauty Wave', '寻找我的专属美肌罗盘')) + '</h2>' +
        '<p class="lead">' + esc(pick('부산의 서로 다른 청정 비경과 바이오 기술을 간직한 5개의 대표 로컬 브랜드 중 지금 당신의 피부 컨디션, 일상 웰니스 철학, 감각의 결에 어울리는 최적의 메디컬 표준을 찾아 드립니다.',
          'Among five iconic local brands representing Busan\'s natural beauty and advanced bio-tech, find the clinical matching standard for your current skin type and wellness philosophy.',
          '在融合釜山绝美自然景观与尖端生物科技的五家明星企业中，结合您当下的肌肤状态、日常养生哲学与感官喜好，为您匹配量身打造的医学级护肤对策。')) + '</p></div>' +
        '<div class="rule thin" style="margin:0 auto"></div>' +
        '<div class="qcards">' +
        '<div><p class="k">01. ' + esc(pick('피부고민', 'Skin Concerns', '肌肤烦恼')) + '</p>' +
        '<p class="v">' + esc(pick('속 당김, 탄력 결함, 극민감 장벽, 유분 등 고민 체크',
          'Check inner dehydration, wrinkles, sensitivity, or sebum.', '测算深层紧绷、松弛皱纹、极度敏感及出油情况')) + '</p></div>' +
        '<div><p class="k">02. ' + esc(pick('가치와 가치관', 'Brand Values', '纯素理念')) + '</p>' +
        '<p class="v">' + esc(pick('비건 리추얼, 미생물 공학 발효, 정제 천연 성분 선택',
          'Assess botanical rituals, bio-ferments, and green ratings.', '考量发酵生物工程、纯植物天然提取、绿色配方等')) + '</p></div>' +
        '<div><p class="k">03. ' + esc(pick('감각과 텍스처', 'Scent & Texture', '感官偏好')) + '</p>' +
        '<p class="v">' + esc(pick('피톤치드 허브향, 무향, 우아한 동백 아로마 등 취향 반영',
          'Match phytoncide herbal, unscented, or royal camellia.', '根据松树杀菌素、无香型或幽雅山茶香进行匹配')) + '</p></div>' +
        '</div>' +
        '<button class="btn btn-solid" style="padding:16px 34px;font-size:13px;margin:0 auto" ' +
        'id="start-quiz-button">' +
        esc(pick('스킨케어 컴퍼스 시작하기', 'Start Skincare Compass', '立即开启肌肤诊断')) + ' →</button>' +
        '</div>';
    } else if (q.step === 'questions') {
      var item = qs[q.idx];
      inner = '<div class="qtop">' +
        '<button data-quiz="prev">‹ ' + esc(pick('이전으로', 'Prev', '上一步')) + '</button>' +
        '<span>QUESTION ' + (q.idx + 1) + ' OF ' + qs.length + '</span></div>' +
        '<div class="qbar"><i style="width:' + ((q.idx + 1) / qs.length * 100) + '%"></i></div>' +
        '<span class="qstep">Step ' + pad(q.idx + 1) + '</span>' +
        '<h3 class="qq">' + esc(item.question) + '</h3>' +
        '<div class="qopts">' + item.options.map(function (o, i) {
          return '<button class="qopt" data-quiz="answer" data-val="' + esc(o.value) + '">' +
            '<span class="ic">' + (QICON[o.iconName] || '✦') + '</span>' +
            '<span class="tx"><span class="t1">' + esc(o.text) + '</span>' +
            '<span class="t2">' + esc(o.description) + '</span></span>' +
            '<span class="arw">›</span></button>';
        }).join('') + '</div>';
    } else {
      var votes = {}, best = brands()[0].id, mx = 0;
      q.answers.forEach(function (v) { votes[v] = (votes[v] || 0) + 1; });
      Object.keys(votes).forEach(function (k) { if (votes[k] > mx) { mx = votes[k]; best = k; } });
      var b = brandById(best);
      var rec = products().filter(function (p) { return p.brandId === b.id; })[0] || products()[0];

      inner = '<div class="qres">' +
        '<div style="text-align:center;display:grid;gap:12px">' +
        '<span class="eyebrow" style="color:var(--gold)">Compass Alignment Decided</span>' +
        '<h2 style="font-size:clamp(24px,3.8vw,38px);font-weight:700;' +
        'letter-spacing:.02em;color:var(--ink)">' +
        esc(pick('당신과 가장 어울리는 뷰티 물결', 'Your Ideal Skincare Destination', '最适合您的美丽浪潮')) + '</h2>' +
        '<div class="rule thin" style="margin:0 auto;background:var(--brand)"></div></div>' +

        '<div class="qmatch"><div class="im"><img src="' + img(b.image) + '" alt="' + esc(b.name) + '"></div>' +
        '<div class="bd"><div style="display:flex;flex-wrap:wrap;align-items:center;gap:10px">' +
        (subEn(b) ? '<span class="chip round brandy">' + esc(subEn(b)) + '</span>' : '') +
        '<span style="font-family:var(--font);font-size:12px;color:var(--brand-mid)">98% MATCH RATING</span></div>' +
        '<h3>' + esc(b.name) + '<small>(' + esc(b.location) + ')</small></h3>' +
        '<p class="cq">“' + esc(b.concept) + '”</p>' +
        '<p class="ds">' + esc(b.description) + '</p></div></div>' +

        (rec ? '<div><div class="blk">Recommended Signature Item (' +
          esc(pick('추천 시그니처 아이템', 'Recommended Item', '推荐经典单品')) + ')</div>' +
          '<div class="qrec"><div class="lf"><div class="th">' + imgTag(rec.image, rec.name, rec.brandId) + '</div>' +
          '<div><span class="cat">' + esc(rec.category) + '</span><h5>' + esc(rec.name) + '</h5>' +
          '<span class="pz">' + esc(priceText(rec)) + '</span></div></div>' +
          storeLink(rec, 'btn btn-sm btn-sq btn-solid',
            pick('공식몰에서 보기', 'View on store', '前往商城查看')) + '</div></div>' : '') +

        '<div class="qfoot"><button class="linkbtn" data-quiz="retry">↺ ' +
        esc(pick('다시 테스트하기', 'Retry Finder', '重新诊断')) + '</button>' +
        '<div style="display:flex;flex-wrap:wrap;gap:12px">' +
        '<button class="btn btn-soft" data-shop="' + b.id + '">' +
        esc(pick('이 브랜드 품목만 구경하기', 'Explore This Brand', '仅浏览该品牌单品')) + '</button>' +
        '<button class="btn btn-solid" data-shop="All">' +
        esc(pick('모든 입점 브랜드 보기', 'View All Brands', '查看所有入驻品牌')) + '</button>' +
        '</div></div></div>';
    }

    return '<div class="quizpanel glass">' +
      '<button class="back" data-quiz="exit">‹ ' +
      esc(pick('이벤트 목록으로 돌아가기', 'Back to Events', '返回活动列表')) + '</button>' +
      inner + '</div>';
  }

  /* =========================================================
     COMMUNITY (Community.tsx)
     ========================================================= */
  var BOARDS = [
    { id: 'all', k: 'allBoards', ic: '▤' },
    { id: 'review', k: 'boardReview', ic: '★' },
    { id: 'question', k: 'boardQuestion', ic: '?' },
    { id: 'free', k: 'boardFree', ic: '💬' }
  ];
  /* 브랜드명·시드 게시글이 바뀌면 반드시 뒤 숫자를 올릴 것.
     올리지 않으면 예전에 방문한 브라우저가 낡은 데이터를 계속 보여준다. */
  var POSTS_KEY = 'bbeauty_community_posts_v4';

  function loadPosts() {
    try {
      var raw = localStorage.getItem(POSTS_KEY);
      if (raw) {
        S.posts = JSON.parse(raw).map(function (p) {
          p.boardCategory = p.boardCategory || 'review'; return p;
        });
        return;
      }
      S.posts = window.SEED_POSTS.slice();
      localStorage.setItem(POSTS_KEY, JSON.stringify(S.posts));
    } catch (e) { S.posts = window.SEED_POSTS.slice(); }
  }
  /* 커뮤니티 글 번역 — 영어·중국어에서는 posts_tr.json 의 내용을 대신 보여준다.
     번역이 없는 글(사용자가 직접 쓴 글 등)은 원문 그대로. */
  function postTr(p) {
    if (S.lang === 'KR' || !p || !window.POSTS_TR) return p;
    var tr = window.POSTS_TR[S.lang];
    var t = tr && tr[p.id];
    if (!t) return p;
    var out = {};
    for (var k in p) { if (Object.prototype.hasOwnProperty.call(p, k)) out[k] = p[k]; }
    if (t.title) out.title = t.title;
    if (t.content) out.content = t.content;
    if (t.writer) out.writer = t.writer;
    if (t.productName) out.productName = t.productName;
    if (t.comments && t.comments.length && p.comments) {
      out.comments = p.comments.map(function (c, i) {
        var tc = t.comments[i];
        if (!tc) return c;
        var o = {};
        for (var k2 in c) { if (Object.prototype.hasOwnProperty.call(c, k2)) o[k2] = c[k2]; }
        if (tc.writer) o.writer = tc.writer;
        if (tc.content) o.content = tc.content;
        return o;
      });
    }
    return out;
  }

  function savePosts() { try { localStorage.setItem(POSTS_KEY, JSON.stringify(S.posts)); } catch (e) { } }

  function postProduct(post) {
    return productById(post.productId) ||
      products().filter(function (p) { return p.brandId === post.brandId; })[0] || products()[0];
  }
  function boardMeta(id) {
    return BOARDS.filter(function (b) { return b.id === id; })[0] || BOARDS[1];
  }
  function boardBadge(id) {
    var m = boardMeta(id), t = TC();
    return '<span class="bb ' + m.id + '">' + m.ic + ' ' + esc(t[m.k]) + '</span>';
  }

  function viewCommunity() {
    var t = TC();
    if (S.comm.state === 'write') return commWrite();
    if (S.comm.state === 'detail') return commDetail();

    var list = S.posts.filter(function (p) {
      if (S.comm.cat !== 'all' && (p.boardCategory || 'review') !== S.comm.cat) return false;
      if (S.comm.brandTab !== 'all' && p.brandId !== S.comm.brandTab) return false;
      var q = S.comm.q.trim().toLowerCase();
      if (q) {
        var tp = postTr(p);
        var s = (tp.title + ' ' + tp.content + ' ' + (tp.productName || '') + ' ' + tp.writer).toLowerCase();
        if (s.indexOf(q) === -1) return false;
      }
      return true;
    });

    var side = '<aside class="commside"><div class="box">' +
      '<div class="bh"><span>' + esc(t.boardCategoryLabel) + '</span><span>▤</span></div>' +
      '<div class="bcats">' + BOARDS.map(function (b) {
        var n = b.id === 'all' ? S.posts.length
          : S.posts.filter(function (p) { return (p.boardCategory || 'review') === b.id; }).length;
        return '<button class="bcat' + (S.comm.cat === b.id ? ' on' : '') + '" data-cc="' + b.id + '">' +
          '<span class="lf"><span>' + b.ic + '</span><span>' + esc(t[b.k]) + '</span></span>' +
          '<span class="cn">' + n + '</span></button>';
      }).join('') + '</div>' +
      '<div class="hr"></div>' +
      '<button class="btn btn-solid btn-sq" style="width:100%" id="community-write-trigger">＋ ' +
      esc(t.writeBtn) + '</button></div></aside>';

    var main = '<div>' +
      '<div class="filterbar"><div class="in">' +
      '<div class="btabs"><button class="btab' + (S.comm.brandTab === 'all' ? ' on' : '') + '" data-cb="all">' +
      esc(t.allBrands) + '</button>' +
      brands().map(function (b) {
        return '<button class="btab' + (S.comm.brandTab === b.id ? ' on' : '') + '" data-cb="' + b.id + '">' +
          esc(S.lang === 'KR' ? b.name : b.englishName) + '</button>';
      }).join('') + '</div>' +
      '<div class="sbox full" style="max-width:380px;width:100%"><span class="mag">⌕</span>' +
      '<input id="community-search-input" value="' + esc(S.comm.q) + '" placeholder="' +
      esc(t.searchPlaceholder) + '"></div></div></div>' +

      (list.length ? '<div class="posts">' + list.map(function (p0) {
        var p = postTr(p0);
        var prod = postProduct(p);
        return '<button class="post" id="post-card-' + esc(p.id) + '" data-cpost="' + esc(p.id) + '">' +
          '<span class="th">' + imgTag(prod.image, '', prod.brandId, ' loading="lazy"') +
          '<span class="pc">' + esc(prod.category) + '</span></span>' +
          '<span class="bd">' +
          '<span class="pbadges">' + boardBadge(p.boardCategory || 'review') +
          '<span class="bb brandtag">' + esc(brandById(p.brandId).name) + '</span>' +
          (p.rating ? starRow(p.rating) : '') +
          (p.fromOfficial ? '<span class="syncpill ok">' + esc(pick('공식몰', 'Official', '官方')) + '</span>' : '') + '</span>' +
          (p.productName ? '<span class="ptag">🏷 <span>' + esc(p.productName) + '</span></span>' : '') +
          '<span><h4>' + esc(p.title) + '</h4><span class="ex">' + esc(p.content) + '</span></span>' +
          '</span>' +
          '<span class="meta"><span class="w">👤 ' + esc(p.writer) + '</span>' +
          '<span class="r"><span class="cbox">💬 ' + (p.comments ? p.comments.length : 0) + '</span>' +
          '<span>' + esc(p.date) + '</span></span></span></button>';
      }).join('') + '</div>'
        : '<div class="empty"><div class="ic">◌</div><p>' + esc(t.noResults) + '</p></div>') +
      '</div>';

    return '<section class="sec view" id="community-main-section"><div class="wrap">' +
      '<div class="headc"><span class="eyebrow">Busan B-Beauty cooperative</span>' +
      '<h2>' + esc(t.title) + '</h2><div class="rule thin"></div>' +
      '<p>' + esc(t.subtitle) + '</p></div>' +
      '<div class="commgrid">' + side + main + '</div></div></section>';
  }

  function commWrite() {
    var t = TC(), f = S.comm.form;
    var bp = products().filter(function (p) { return p.brandId === f.brand; });
    if (!f.product && bp.length) f.product = bp[0].id;
    var sel = productById(f.product);

    return '<section class="sec view"><div class="wrap">' +
      '<div class="formpanel">' +
      '<div class="formhead"><h3>✦ ' + esc(t.writeTitle) + '</h3>' +
      (f.cat === 'review' ? '<div class="ratebox"><div class="sb">' +
        [1, 2, 3, 4, 5].map(function (i) {
          return '<button data-star="' + i + '" class="' + (i <= f.rating ? 'on' : '') + '">★</button>';
        }).join('') + '</div><span class="num">' + f.rating + '.0</span></div>' : '') +
      '</div>' +

      '<div class="field"><label>' + esc(t.boardCategoryLabel) + '</label>' +
      '<div class="cat3">' + BOARDS.slice(1).map(function (b) {
        return '<button data-fcat="' + b.id + '" class="' + (f.cat === b.id ? 'on' : '') + '">' +
          b.ic + ' ' + esc(t[b.k]) + '</button>';
      }).join('') + '</div></div>' +

      '<div class="field"><label>' + esc(t.writer) + '</label>' +
      '<input id="f-writer" value="' + esc(f.writer) + '" placeholder="' + esc(t.inputWriter) + '"></div>' +

      '<div class="grid2">' +
      '<div class="field"><label>' + esc(t.brandLabel) + '</label><select id="f-brand">' +
      brands().map(function (b) {
        return '<option value="' + b.id + '"' + (f.brand === b.id ? ' selected' : '') + '>' + esc(b.name) + '</option>';
      }).join('') + '</select></div>' +
      '<div class="field"><label>' + esc(t.productLabel) + '</label><select id="f-prod">' +
      bp.map(function (p) {
        return '<option value="' + p.id + '"' + (f.product === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>';
      }).join('') + '</select></div></div>' +
      '<p style="margin:-12px 0 0;font-size:11.5px;font-weight:400;color:var(--brand-mid)">' +
      esc(t.selectProductPrompt) + '</p>' +

      (sel ? '<div class="prodprev">' + imgTag(sel.image, sel.name, sel.brandId) +
        '<div><div class="k">' + esc(t.productPreviewTitle) + '</div>' +
        '<div class="v">' + esc(sel.name) + '</div></div></div>' : '') +

      '<div class="field"><label>' + esc(t.titleLabel) + '</label>' +
      '<input id="f-title" value="' + esc(f.title) + '" placeholder="' + esc(t.inputTitle) + '"></div>' +
      '<div class="field"><label>' + esc(t.contentLabel) + '</label>' +
      '<textarea id="f-content" style="min-height:150px" placeholder="' + esc(t.inputContent) + '">' +
      esc(f.content) + '</textarea></div>' +

      '<div class="formfoot">' +
      '<button class="btn btn-line btn-sq" id="form-cancel-btn">' + esc(t.cancel) + '</button>' +
      '<button class="btn btn-solid btn-sq" id="form-submit-btn">' + esc(t.submit) + '</button>' +
      '</div></div></div></section>';
  }

  function commDetail() {
    var t = TC();
    var p0 = S.posts.filter(function (x) { return x.id === S.comm.post; })[0];
    if (!p0) { S.comm.state = 'list'; return viewCommunity(); }
    var p = postTr(p0);
    var prod = postProduct(p);

    return '<section class="sec view"><div class="wrap"><div class="detailwrap">' +
      '<button class="linkbtn" id="back-to-community-list">← ' + esc(t.backToList) + '</button>' +

      '<div class="postfull">' +
      '<div class="ph"><div><span class="pbadges">' + boardBadge(p.boardCategory || 'review') +
      '<span class="bb brandtag">' + esc(brandById(p.brandId).name) + '</span></span>' +
      '<h3>' + esc(p.title) + '</h3></div>' +
      (p.rating ? '<div class="ratecol">' + starRow(p.rating) +
        '<span class="lbl">' + p.rating + '.0 / 5.0</span></div>' : '') + '</div>' +

      '<div class="prodbanner">' + imgTag(prod.image, prod.name, prod.brandId) +
      '<div class="bd"><div class="r1"><span class="b1">' + esc(brandById(prod.brandId).name) + '</span>' +
      '<span class="b2">• ' + esc(prod.category) + '</span></div>' +
      '<h5>' + esc(S.lang === 'KR' ? prod.name : prod.englishName) + '</h5>' +
      '<p class="pz">' + esc(priceText(prod)) + '</p></div></div>' +

      '<div class="wmeta"><span class="w">👤 <b>' + esc(p.writer) + '</b></span>' +
      '<span>📅 ' + esc(p.date) + '</span>' +
      '<span>💬 ' + (p.comments ? p.comments.length : 0) + '</span></div>' +

      '<p class="postbody">' + esc(p.content) + '</p>' +
      (p.sourceUrl ? '<a class="btn btn-line btn-sq" style="justify-self:start" href="' + esc(p.sourceUrl) + '" target="_blank" rel="noopener">' + esc(pick('공식몰에서 원문 보기', 'Read original on official store', '前往官方商城查看原文')) + ' ↗</a>' : '') + '</div>' +

      '<div><div class="blk">' + esc(t.comments) + ' (' + (p.comments ? p.comments.length : 0) + ')</div>' +
      (p.comments && p.comments.length ? '<div class="comments">' + p.comments.map(function (c) {
        return '<div class="comment"><div class="cw">' + esc(c.writer) + ' <small>' + esc(c.date) +
          '</small></div><p class="cc">' + esc(c.content) + '</p></div>';
      }).join('') + '</div>'
        : '<p style="margin:0;font-size:13px;font-weight:400;color:var(--brand-mid)">' + esc(t.noComments) + '</p>') +
      '</div>' +

      '<div class="formpanel" style="max-width:none;margin:0">' +
      '<div class="blk" style="margin:0">' + esc(t.addComment) + '</div>' +
      '<div class="grid2">' +
      '<div class="field"><label>' + esc(t.commentWriterLabel) + '</label>' +
      '<input id="cm-writer" placeholder="' + esc(t.commentWriterLabel) + '"></div>' +
      '<div class="field"><label>' + esc(t.addComment) + '</label>' +
      '<input id="cm-content" placeholder="' + esc(t.commentPlaceholder) + '"></div></div>' +
      '<div class="formfoot"><button class="btn btn-solid btn-sq" id="comment-submit">' +
      esc(t.commentSubmit) + '</button></div></div>' +

      '</div></div></section>';
  }

  /* =========================================================
     FOOTER (App.tsx footer) / TOAST
     ========================================================= */
  function footer() {
    return '<footer id="cooperative-footer"><div class="wrap"><div class="fgrid">' +
      '<div><span class="flogo">B<em>-</em>BEAUTY</span>' +
      '<p class="fslogan">B-Wave: Here Begins the Next Beauty Standard</p>' +
      '<p>' + esc(T('footer.description')) + '</p>' +
      '</div>' +

      '<div><h5>' + esc(T('footer.brands_title')) + '</h5><ul>' +
      brands().map(function (b) {
        return '<li><button id="footer-brand-' + b.id + '" data-shop="' + b.id + '">' +
          esc(nameFull(b)) + '</button></li>';
      }).join('') + '</ul></div>' +

      '<div><h5>Platform Menu</h5><ul class="menu">' +
      VIEWS.map(function (v) {
        return '<li><button data-go="' + v.id + '">' + esc(T(v.key)) + '</button></li>';
      }).join('') + '</ul></div>' +

      '</div>' +

      '<div class="fbot"><span>© 2026 B-Beauty Cooperative Federation. All rights reserved.</span>' +
      '<span class="rt"><button data-go="brands">' + esc(T('footer.terms')) + '</button><span>|</span>' +
      '<button data-go="quiz">' + esc(T('footer.privacy')) + '</button><span>|</span>' +
      '<span class="ver">✦ B-Wave Standard Ver 1.4</span></span></div>' +
      '</div></footer>';
  }

  function toast() {
    if (!S.toast) return '';
    return '<div class="toast"><span class="ic">✓</span>' +
      '<div class="bd"><p>' + esc(S.toast) + '</p></div>' +
      '<button class="xbtn" id="close-toast">✕</button></div>';
  }

  /* =========================================================
     RENDER
     ========================================================= */
  function render() {
    var main;
    switch (S.view) {
      case 'home': main = viewHome(); break;
      case 'intro': main = viewIntro(); break;
      case 'brands': main = '<div class="view">' + brandShowcase() + '</div>'; break;
      case 'products': main = viewProducts(); break;
      case 'quiz': main = viewQuizPage(); break;
      case 'community': main = viewCommunity(); break;
      default: main = viewHome();
    }
    document.body.innerHTML = navbar() + '<main class="main">' + main + '</main>' + footer() +
      productModal() + dossier() + eventDetailModal() + videoModal() + allEventsModal() + toast();
    document.body.style.overflow =
      (S.activeProduct || S.dossier || S.evDetail || S.video || S.evAll) ? 'hidden' : '';
    wire();
  }

  /* =========================================================
     WIRING
     ========================================================= */
  function on(sel, fn) { Array.prototype.forEach.call(document.querySelectorAll(sel), fn); }
  function click(sel, fn) { on(sel, function (b) { b.addEventListener('click', fn.bind(null, b)); }); }

  function wire() {
    /* --- 이동 --- */
    click('[data-go]', function (b) { go(b.getAttribute('data-go')); });
    click('[data-lang]', function (b) { S.lang = b.getAttribute('data-lang'); render(); });
    click('[data-hero-explore]', function () {
      S.view = 'intro';
      var t = el('main-content-anchor');
      if (t) t.scrollIntoView({ behavior: 'smooth' });
      else window.scrollTo({ top: window.innerHeight - 80, behavior: 'smooth' });
    });
    var mt = el('mobile-menu-toggle');
    if (mt) mt.addEventListener('click', function () { S.mobileMenu = !S.mobileMenu; render(); });

    click('[data-navbrand]', function (b, e) {
      e.stopPropagation(); go('brands', { brandId: b.getAttribute('data-navbrand') });
    });
    click('[data-navshop]', function (b, e) {
      e.stopPropagation(); go('products', { brandFilter: b.getAttribute('data-navshop') });
    });
    click('[data-shop]', function (b, e) {
      e.stopPropagation();
      S.dossier = false; S.quiz.active = false;
      go('products', { brandFilter: b.getAttribute('data-shop') });
    });

    /* --- 브랜드 쇼케이스 --- */
    click('[data-brand]', function (b) { S.brandId = b.getAttribute('data-brand'); render(); });
    click('[data-dossier]', function (b) {
      S.brandId = b.getAttribute('data-dossier'); S.dossier = true; render();
    });

    /* --- 브랜드 영상 --- */
    click('[data-video]', function (b) { S.video = b.getAttribute('data-video'); render(); });
    click('[data-vpage]', function (b) {
      S.vidPage = parseInt(b.getAttribute('data-vpage'), 10) || 0; render();
    });
    click('[data-vnav]', function (b) {
      videoGo(b.getAttribute('data-vnav') === 'next' ? 1 : -1);
    });
    /* 손가락으로 좌우로 밀어 넘기기 */
    var vd = el('video-deck');
    if (vd) {
      var sx = 0, sy = 0, moved = false;
      vd.addEventListener('touchstart', function (e) {
        var t = e.changedTouches[0]; sx = t.clientX; sy = t.clientY; moved = false;
      }, { passive: true });
      vd.addEventListener('touchmove', function () { moved = true; }, { passive: true });
      vd.addEventListener('touchend', function (e) {
        if (!moved) return;
        var t = e.changedTouches[0];
        var dx = t.clientX - sx, dy = t.clientY - sy;
        /* 세로 스크롤과 헷갈리지 않도록 가로 이동이 확실할 때만 */
        if (Math.abs(dx) < 50 || Math.abs(dx) < Math.abs(dy) * 1.5) return;
        videoGo(dx < 0 ? 1 : -1);
      }, { passive: true });
    }

    /* --- 제품 --- */
    click('[data-open]', function (b, e) {
      e.stopPropagation(); S.activeProduct = b.getAttribute('data-open'); render();
    });
    on('[data-stop]', function (n) { n.addEventListener('click', function (e) { e.stopPropagation(); }); });
    /* 미리보기 iframe 처럼 새 탭 열기가 막힌 곳에서도 링크가 동작하도록 */
    on('[data-ext]', function (n) {
      n.addEventListener('click', function (e) {
        var url = n.getAttribute('data-ext');
        if (!url) return;
        e.preventDefault(); e.stopPropagation();
        var win = null;
        try { win = window.open(url, '_blank', 'noopener'); } catch (err) { win = null; }
        if (!win) { try { window.top.location.href = url; } catch (err2) { window.location.href = url; } }
      });
    });
    click('[data-bf]', function (b) {
      S.brandFilter = b.getAttribute('data-bf'); S.category = 'All'; S.concern = 'All'; render();
    });
    click('[data-cat]', function (b) { S.category = b.getAttribute('data-cat'); render(); });
    click('[data-con]', function (b) { S.concern = b.getAttribute('data-con'); render(); });
    function resetFilters() {
      S.brandFilter = 'All'; S.category = 'All'; S.concern = 'All'; S.query = ''; S.sort = 'featured'; render();
    }
    var rf = el('reset-filters'); if (rf) rf.addEventListener('click', resetFilters);
    var cf = el('clear-all-filters'); if (cf) cf.addEventListener('click', resetFilters);

    /* --- 오버레이 닫기 --- */
    on('[data-close]', function (n) {
      n.addEventListener('click', function (e) {
        if (e.target !== n) return;
        var w = n.getAttribute('data-close');
        if (w === 'product') S.activeProduct = null;
        if (w === 'dossier') S.dossier = false;
        if (w === 'ev') S.evDetail = null;
        if (w === 'video') S.video = null;
        if (w === 'evall') S.evAll = false;
        render();
      });
    });

    /* --- 토스트 --- */
    var tx = el('close-toast'); if (tx) tx.addEventListener('click', function () { S.toast = null; render(); });

    /* --- 이벤트 / 공지 --- */
    click('[data-evtab]', function (b) {
      S.evTab = b.getAttribute('data-evtab');
      if (S.evTab === 'events') S.quiz.active = false;
      render();
    });
    click('[data-evpage]', function (b) {
      if (b.disabled) return;
      S.evPage = parseInt(b.getAttribute('data-evpage'), 10);
      render();
      var t = el('events-notices-section'); if (t) t.scrollIntoView({ behavior: 'smooth' });
    });
    click('[data-evall]', function () { S.evAll = true; render(); });
    click('[data-ev]', function (b) {
      if (b.disabled) return;
      S.evAll = false;
      var a = b.getAttribute('data-ev');
      if (a === 'quiz') S.quiz = { active: true, step: 'welcome', idx: 0, answers: [] };
      else if (a === 'coupon') {
        S.coupon = true;
        showToast(pick('웰컴 15% 할인 바우처가 발급되었습니다.',
          'Your 15% welcome voucher has been issued.', '欢迎 15% 折扣券已发放。'));
      } else if (a.indexOf('detail:') === 0) S.evDetail = a.split(':')[1];
      render();
    });
    click('[data-ncat]', function (b) {
      S.noticeCat = b.getAttribute('data-ncat'); S.noticeOpen = null; render();
    });
    click('[data-notice]', function (b) {
      var id = parseInt(b.getAttribute('data-notice'), 10);
      S.noticeOpen = S.noticeOpen === id ? null : id; render();
    });
    debounced('notice-q', function (v) { S.noticeQ = v; S.noticeOpen = null; });

    /* --- 퀴즈 --- */
    var sq = el('start-quiz-button');
    if (sq) sq.addEventListener('click', function () {
      S.quiz.step = 'questions'; S.quiz.idx = 0; S.quiz.answers = []; render();
    });
    click('[data-quiz]', function (b) {
      var a = b.getAttribute('data-quiz'), qs = D().quiz;
      if (a === 'exit') { S.quiz.active = false; S.quiz.step = 'welcome'; }
      else if (a === 'prev') {
        if (S.quiz.idx > 0) S.quiz.idx -= 1; else S.quiz.step = 'welcome';
      }
      else if (a === 'retry') { S.quiz.step = 'questions'; S.quiz.idx = 0; S.quiz.answers = []; }
      else if (a === 'answer') {
        S.quiz.answers[S.quiz.idx] = b.getAttribute('data-val');
        if (S.quiz.idx < qs.length - 1) S.quiz.idx += 1; else S.quiz.step = 'results';
      }
      render();
    });

    /* --- 커뮤니티 --- */
    click('[data-cc]', function (b) { S.comm.cat = b.getAttribute('data-cc'); render(); });
    click('[data-cb]', function (b) { S.comm.brandTab = b.getAttribute('data-cb'); render(); });
    debounced('community-search-input', function (v) { S.comm.q = v; });
    var cw = el('community-write-trigger');
    if (cw) cw.addEventListener('click', function () {
      S.comm.state = 'write'; window.scrollTo({ top: 0, behavior: 'smooth' }); render();
    });
    var cc = el('form-cancel-btn');
    if (cc) cc.addEventListener('click', function () { S.comm.state = 'list'; render(); });
    var bk = el('back-to-community-list');
    if (bk) bk.addEventListener('click', function () {
      S.comm.state = 'list'; S.comm.post = null; render();
    });
    click('[data-cpost]', function (b) {
      S.comm.post = b.getAttribute('data-cpost'); S.comm.state = 'detail';
      window.scrollTo({ top: 0, behavior: 'smooth' }); render();
    });
    click('[data-star]', function (b) {
      syncForm(); S.comm.form.rating = parseInt(b.getAttribute('data-star'), 10); render();
    });
    click('[data-fcat]', function (b) {
      syncForm(); S.comm.form.cat = b.getAttribute('data-fcat'); render();
    });
    ['f-brand', 'f-prod'].forEach(function (id) {
      var n = el(id); if (!n) return;
      n.addEventListener('change', function () {
        syncForm();
        if (id === 'f-brand') {
          var bp = products().filter(function (p) { return p.brandId === S.comm.form.brand; });
          S.comm.form.product = bp.length ? bp[0].id : '';
        }
        render();
      });
    });
    var fs = el('form-submit-btn');
    if (fs) fs.addEventListener('click', function () {
      syncForm();
      var f = S.comm.form, t = TC();
      if (!f.writer.trim() || !f.title.trim() || f.content.trim().length < 10) { alert(t.inputContent); return; }
      var prod = productById(f.product);
      S.posts.unshift({
        id: 'post-' + Date.now(), boardCategory: f.cat, brandId: f.brand, productId: f.product,
        productName: prod ? prod.name : '', title: f.title, content: f.content,
        rating: f.cat === 'review' ? f.rating : undefined, writer: f.writer,
        date: new Date().toISOString().slice(0, 10), comments: []
      });
      savePosts();
      S.comm.form = { cat: 'review', brand: 'amaranth', product: '', rating: 5, writer: '', title: '', content: '' };
      S.comm.state = 'list';
      showToast(t.successAlert);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      render();
    });
    var cs = el('comment-submit');
    if (cs) cs.addEventListener('click', function () {
      var w = el('cm-writer'), c = el('cm-content');
      if (!w || !c || !w.value.trim() || !c.value.trim()) return;
      S.posts.forEach(function (p) {
        if (p.id === S.comm.post) {
          p.comments = p.comments || [];
          p.comments.push({
            id: 'c' + Date.now(), writer: w.value.trim(), content: c.value.trim(),
            date: new Date().toISOString().slice(0, 10)
          });
        }
      });
      savePosts(); render();
    });

    /* --- 검색바 --- */
    ['home', 'nav', 'mob', 'prod'].forEach(wireSearch);

    /* --- ESC --- */
    document.onkeydown = function (e) {
      if (e.key !== 'Escape') return;
      if (S.activeProduct || S.dossier || S.evDetail || S.video || S.evAll) {
        S.activeProduct = null; S.dossier = false; S.evDetail = null; S.video = null;
        S.evAll = false; render();
      }
    };
  }

  /* 입력 후 debounce 렌더 + 포커스 유지 */
  function debounced(id, setter) {
    var n = el(id); if (!n) return;
    n.addEventListener('input', function () {
      clearTimeout(n._t);
      var v = n.value;
      n._t = setTimeout(function () {
        setter(v); render();
        var x = el(id);
        if (x) { x.focus(); x.setSelectionRange(x.value.length, x.value.length); }
      }, 280);
    });
  }

  function syncForm() {
    var f = S.comm.form, g = function (id) { var n = el(id); return n ? n.value : null; };
    var v;
    if ((v = g('f-brand')) !== null) f.brand = v;
    if ((v = g('f-prod')) !== null) f.product = v;
    if ((v = g('f-writer')) !== null) f.writer = v;
    if ((v = g('f-title')) !== null) f.title = v;
    if ((v = g('f-content')) !== null) f.content = v;
  }

  /* 스크롤 상태 (Navbar useEffect) */
  window.addEventListener('scroll', function () {
    var s = window.scrollY > 50;
    if (s === S.scrolled) return;
    S.scrolled = s;
    var n = document.querySelector('.nav');
    if (n) n.classList.toggle('scrolled', s);
  }, { passive: true });

  /* =========================================================
     BOOT
     ========================================================= */
  loadPosts();
  var h = (location.hash || '').slice(1);
  if (VIEWS.some(function (v) { return v.id === h; })) S.view = h;

  render();
})();
